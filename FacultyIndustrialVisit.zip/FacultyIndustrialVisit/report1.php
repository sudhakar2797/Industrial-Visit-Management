

<?php  if (session_status() == PHP_SESSION_NONE) {session_start();}
require 'dbconnect.php'; 
$faf="";$entry=0;
        if((isset($_POST['first']))&&(isset($_SESSION['smid']))){
            $id=$_SESSION['smid'];
              $staffID=$_SESSION['log'];
       $sql = "SELECT * FROM  staffdetails  WHERE  StaffId='$staffID'";
                            $result = $conn->query($sql);
                                if($result->num_rows >0){
                                    while($row = $result->fetch_assoc()){
                                $staffname=$row['StaffName'];}}
            $iphone=$_POST['iphone'];
            $email=$_POST['email'];
            $head=$_POST['head'];
            $headphone=$_POST['pphone'];
            $branch=$_POST['branch'];
            $capacity=$_POST['capacity'];
            $turnover=$_POST['turnover'];
            $cusomer=$_POST['customer'];
            $dep=$_POST['dep'];
            $noe=$_POST['noe'];
            $top=$_POST['top'];
            $aop=$_POST['aop'];
            $euop=$_POST['euop'];
if(isset($_POST['manu'])){
    $faf=$faf.$_POST['manu'];
}
if(isset($_POST['test'])){
    $faf=$faf." , ".$_POST['test'];
}
if(isset($_POST['research'])){
    $faf=$faf." , ".$_POST['research'];
}
            $doc=$_POST['doc'];
            
            
            $stmt= $conn->prepare("INSERT INTO report(id,staffname, industryphoneno, emailid_website, nameof_MD_others, MD_others_phoneno, branches, productionrate, turnover, customers, deportments, noofemployees, typeofproduct, applicationoftheproduct, enduser, facilities, detailsofconsultant) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("isississsssssssss",$id,$staffname,$iphone,$email,$head,$headphone,$branch,$capacity,$turnover,$cusomer,$dep,$noe,$top,$aop,$euop,$faf,$doc);
                            if($stmt->execute()){
                                $entry=1;
                                
                            }   else {
                                $_SESSION['reerror']="Check Your Data,Please Try Again";
                                
                                 $sql = "SELECT * FROM  report  WHERE  id='$id'";
                            $result = $conn->query($sql);
                                if($result->num_rows >0){
                                     if(!empty($_SESSION['reerror'])){  unset($_SESSION['reerror']);}
                                               $entry=1;                         
                                }else{
                                     header("location:report.php");                         
                                }
                            }
        

}else {     $_SESSION['reerror']="Please Don't Enter Unwanted Data";
     header("location:report.php");                         }
         




mysqli_close($conn);
?>

<?php 
if($entry==1){?>
    
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Login Form</title>
  <style> button::-moz-focus-inner {
                    border: 0;
                }
                input[type=button]::-moz-focus-inner {
                    border: 0;
                }</style>
  
  
      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/style1.css">


  
</head>
<body><center><br><br><br><br><br><div class="card" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 2900px"><?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>
                
                
    <div style="background-color: #357ae8; width: 90%;height: 350px;" ><br><br>
<div class="app-title" >
    <h2 style="color:white;font-size: 25px"><b>Industrial Visit Report From</b></h2>			</div>
    <br><br><div class="login" style="width:600px">
        <div class="login-screen" >                    
             <?php if(!empty($_SESSION['reerror'])){?>
                                
            <link href="css/alert.css" rel="stylesheet">
            <div class="alert success"  style="width:50%" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $_SESSION['reerror'];?>
                                     </div>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script><?php }?>
                  
                    <div class="app-title" >
                                        <h2 style="color:black;"><b>Opportunities To Student</b></h2>
			</div> 
                    <form action="report2.php" method="post">
                        <image src="image/header_pic.jpg" height="30px" style="width:100%;"><br><br><br>

                    <input  type="button" class="accordion" value="Industrial Visit                                                                             +">
<div class="panel">
                            <div class="app-title">
                                <h3 style="color: darkmagenta;text-align: left;">Possibilities</h3>
			<label class="switch">
  <input type="checkbox" name="possible" >
  <div class="slider"  style="color: black; font-family: calibri;style:bold;font-size: 25px;">&nbsp;&nbsp;&nbsp;&nbsp;<p style="display: inline;color: white;">yes</p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No</div>
</label>
                  </div>         
                          <div class="app-title">
                                <h3 style="color:mediumblue;text-align: left;">If Yes</h3>
			</div>
<div class="control-group1" align="left"><label><b>  Number of Students  ,  Number of Days</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder="Number of Students" name="nos1" >
				   <input type="text" class="login-field"  placeholder=" Number of Days" name="nod1" >
				</div>
                  
                    <div class="control-group" align="left" ><label><b> Contact Person</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder=" Contact Person" name="cp1" >
				</div> 
                    <div class="control-group" align="left" ><label><b> Department</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder=" Department" name="dep1" >
				</div> 
                     
                    
                    
                        
                    </div>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    <input  type="button" class="accordion" value="Inplant Training                                                                           +" >   
<div class="panel">
 <div class="app-title">
                                <h3 style="color: darkmagenta;text-align: left;">Possibilities</h3>
			<label class="switch">
  <input type="checkbox" name="possible1" >
  <div class="slider"  style="color: black; font-family: calibri;style:bold;font-size: 25px;">&nbsp;&nbsp;&nbsp;&nbsp;<p style="display: inline;color: white;">yes</p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No</div>
</label>
                  </div>         
                          <div class="app-title">
                                <h3 style="color:mediumblue;text-align: left;">If Yes</h3>
			</div>
<div class="control-group1" align="left"><label><b>  Number of Students  ,  Number of Days</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder="Number of Students" name="nos2" >
				   <input type="text" class="login-field"  placeholder=" Number of Days" name="nod2" >
				</div>
                  
                    <div class="control-group" align="left" ><label><b> Contact Person</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder=" Contact Person" name="cp2" >
				</div> 
                    <div class="control-group" align="left" ><label><b> Department</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder=" Department" name="dep2" >
				</div></div>

                    <input  type="button" class="accordion" value="Project Work                                                                               +">
<div id="foo" class="panel">
 <div class="app-title">
                                <h3 style="color: darkmagenta;text-align: left;">Possibilities</h3>
			<label class="switch">
  <input type="checkbox" name="possible2" >
  <div class="slider"  style="color: black; font-family: calibri;style:bold;font-size: 25px;">&nbsp;&nbsp;&nbsp;&nbsp;<p style="display: inline;color: white;">yes</p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No</div>
</label>
                  </div>         
                          <div class="app-title">
                                <h3 style="color:mediumblue;text-align: left;">If Yes</h3>
			</div>
<div class="control-group1" align="left"><label><b>  Number of Students  ,  Number of Days</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder="Number of Students" name="nos3" >
				   <input type="text" class="login-field"  placeholder=" Number of Days" name="nod3" >
				</div>
                  
                    <div class="control-group" align="left" ><label><b> Contact Person</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder=" Contact Person" name="cp3" >
				</div> 
                    <div class="control-group" align="left" ><label><b> Department</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder=" Department" name="dep3" >
				</div></div>
                 
                    <input  type="button" class="accordion" value="Guest Lecture                                                                              +">
<div id="foo" class="panel">
 <div class="app-title">
                                <h3 style="color: darkmagenta;text-align: left;">Possibilities</h3>
			<label class="switch">
  <input type="checkbox" name="possible3" >
  <div class="slider"  style="color: black; font-family: calibri;style:bold;font-size: 25px;">&nbsp;&nbsp;&nbsp;&nbsp;<p style="display: inline;color: white;">yes</p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No</div>
</label>
                  </div>         
                          <div class="app-title">
                                <h3 style="color:mediumblue;text-align: left;">If Yes</h3>
			</div>
<div class="control-group1" align="left"><label><b>  Number of Students  ,  Number of Days</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder="Number of Students" name="nos4" >
				   <input type="text" class="login-field"  placeholder=" Number of Days" name="nod4" >
				</div>
                  
                    <div class="control-group" align="left" ><label><b> Contact Person</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder=" Contact Person" name="cp4" >
				</div> 
                    <div class="control-group" align="left" ><label><b> Department</b></label><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="text" class="login-field"  placeholder=" Department" name="dep4" >
				</div></div>
                 
                                                                   <br> <center><button class="butt" name="second"><span>Next</span></button></center>

                                                                     <br>  <image src="image/header_pic.jpg" height="30px" style="width:100%;">

                    </form></div></div></div></center></body> 
<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].onclick = function(){
        this.classList.toggle("active");
        this.nextElementSibling.classList.toggle("show");
  }
}
</script></html>
<?php }?>
