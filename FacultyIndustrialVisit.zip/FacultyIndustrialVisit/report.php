<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Report Form</title>
 
      <link rel="stylesheet" href="css/style.css">
 <?php    if (session_status() == PHP_SESSION_NONE) {session_start();}
 require 'dbconnect.php';   
                            $subid="";
                            $_SESSION['id']=$_SESSION['log'];
                            $id=$_SESSION['id'];
                            $sql = "SELECT * FROM  faculty  WHERE  StaffId='$id' AND reportstatus='pending'";
                            $result = $conn->query($sql);
                                if($result->num_rows >0){
                                    while($row = $result->fetch_assoc()){
                                        $_SESSION['smid']=$row['id'];
                                          $subid=$_SESSION['smid'];                              }
                                                         }              
                            $sql = "SELECT * FROM  industry  WHERE  id='$subid'";
                            $result = $conn->query($sql);
                                if ($result->num_rows >0){
                                    while($row = $result->fetch_assoc()){
                                        $industryname=$row['industryname']; 
                                        $industrynature=$row['industrynature'];
                                        $industryaddress=$row['industryaddress'];
                                    }
                                                         }
        ?>
            
                  
                 
  
</head>
        <body><center><br><br><br><br><br><div class="card" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); "><?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>
                
      <?php if(!empty($_SESSION['reerror'])){?>
                                
            <link href="css/alert.css" rel="stylesheet">
            <div class="alert success"  style="width:50%" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $_SESSION['reerror'];?>
                                     </div>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script><?php }?>
                
 <link rel="stylesheet" href="css/s.css">

<div class="containe">
  <div class="ard" style="background-color: #357ae8;"></div>
  <div class="ard">
    <h1 class="title" style="font-size: 20px;"> Report Form</h1>
    
        
        
                    <form action="report1.php" method="post">
                        
			
                             <div class="input-container"> 
                            <input type="text"    id="#{label}"  value="<?php if(isset($industryname)){  echo $industryname;}else{    echo ' ';}?>"name="iname" required>
                                   <label for="#{label}">Industry Name *</label> <div class="bar"></div>      </div>
                                            
                                            
                                 <div class="input-container">
                                <input type="text"    id="#{label}"  value="<?php if(isset($industryaddress)){ echo $industryaddress;}else{    echo ' ';}?>"  name="address" required>
                                    <label for="#{label}">Address *</label> <div class="bar"></div>      </div>
                                            
                                            
                                            
                             <div class="input-container">
                                <input type="text"    id="#{label}"    name="iphone" required>
				<label for="#{label}">Industry PhoneNumber / FaxNumber *</label> <div class="bar"></div>      </div>
                                            
                                            
                                            
                             <div class="input-container">
                                <input type="text"    id="#{label}"    name="email" required>
                                    <label for="#{label}">E-MailID / Website *</label> <div class="bar"></div>      </div>
                                            
                                            
                                            
                             <div class="input-container">
				<input type="text"    id="#{label}"   name="head" required>
                            <label for="#{label}">Name of M.D / C.E.O / G.M / OTHERS *</label> <div class="bar"></div>      </div>
                            <p style="color:firebrick;font-size: 16px;font-family: calibri;">* If Others Specify With Designation *</p>

                                            <br><br>
                                            
                             <div class="input-container">
                                <input type="text"    id="#{label}"  name="pphone" required>
                                    <label for="#{label}">Mobile [C.E.O / G.M / OTHERS ] / Fax Number *</label> <div class="bar"></div>      </div>
                                            
                                            
                                            
                                 
                                 <div class="input-container">
                                <input type="text"    id="#{label}"  value="<?php if(isset($industrynature)){  echo $industrynature;}else{    echo ' ';}?>" name="typei" required>
				<label for="#{label}">Type of Industry / Organisation *</label> <div class="bar"></div>      </div>
                            
                                            
                                            
                                 <div class="input-container">
                                    <input type="text"    id="#{label}"  name="branch" required>
                                    <label for="#{label}">Branches *</label> <div class="bar"></div>      </div>
				
                            
                                 <div class="input-container">
                                    <input type="text"    id="#{label}"    name="capacity" required>
				<label for="#{label}">Capacity / Production Rate *</label> <div class="bar"></div>      </div>
                            
                                            
                                            
                                 <div class="input-container">
                                    <input type="text"    id="#{label}"   name="turnover" required>
                                    <label for="#{label}">Turn Over * <i style="color:firebrick;font-size: 16px;font-family: calibri;">[Rs.]</i></label> <div class="bar"></div>      </div>
                            
                                            
       

                                            
                                 <div class="input-container">
                                    <input type="text"    id="#{label}"    name="customer" required>
				<label for="#{label}">Number of Customers *</label> <div class="bar"></div>      </div>

				
                                            
                                 <div class="input-container">
                                    <input type="text"    id="#{label}"   name="dep" required>
                                    <label for="#{label}">Existing Departments *</label> <div class="bar"></div>      </div>
				
                                            
                                            
                                 <div class="input-container">
                                    <input type="text"    id="#{label}"   name="noe" required>
                                    <label for="#{label}">Number of Employees *</label> <div class="bar"></div>      </div>
				
                                            
                                            
                                            
                                 <div class="input-container">
                                    <input type="text"    id="#{label}"    name="top" required>
                                    <label for="#{label}">Type of Product *</label> <div class="bar"></div>      </div>
				
                                            
                                            
                                 <div class="input-container">
                                    <input type="text"    id="#{label}"    name="aop" required>
				<label for="#{label}">Application of the Product *</label> <div class="bar"></div>      </div>

				
                                            
                                            
                                 <div class="input-container">
                                <input type="text"    id="#{label}"    name="euop" required>
                                <label for="#{label}">End User of the Product *</label> <div class="bar"></div>      </div>
        
                                            
                                            
                                 <div class="input-container">
                                    <input type="text"    id="#{label}"   name="doc" required>
                                    <label for="#{label}">Details of Consultant *</label> <div class="bar"></div>      </div>
                                
                                
                                 <div class="input-container"><label for="#{label}">Facilities Available For </label><br><br></div> 
                                                    <input type="checkbox" value="manufacturing" id="checkboxOne" name="manu" checked/>
                                                    <label style="font-size: 18px;" for="checkboxOne" class="checkbox" chec>Manufacturing </label> 
                                                    <input type="checkbox" value="testing" id="checkboxTwo" name="test" />
                                                    <label style="font-size: 18px;" for="checkboxTwo" class="checkbox">Testing </label> 
                                                    <input type="checkbox" value="research" id="checkboxThree" name="research" />
                                                    <label style="font-size: 18px;" for="checkboxThree" class="checkbox">Research </label> 
                                            
                                                    
                                                    <br><br><br><br>
                                                    <div class="button-container"  >
                                                        <center><button class="butt" name="first" style="background-color: #000"><span>Next&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></button></center>
                                                      </div>
                            
                            
                           
   
                      
        
        
        
        
        
        
          </form><?php if(!empty($_SESSION['reerror'])){  unset($_SESSION['reerror']);}?>
  </div>
</div>

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                <br><br>                                      <?php if(!empty($_SESSION['reerror'])){  unset($_SESSION['reerror']);}?>

    <?php include 'home/footer.php';?>
    </div>
              </center>
    
    
    

    
</body>
  
 
</html>
