

<html>
    <head>
        <link rel="stylesheet" href="css/report.css">

        <link rel="stylesheet" href="jq/jquery-ui.css">
        <script src="jq/jquery.js"></script>
        <script src="jq/jquery-ui.js"></script>
           <script type="text/javascript">
$(function() {
    $('.date-picker').datepicker( {
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,
        dateFormat: 'MM yy',
        onClose: function(dateText, inst) { 
            $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
        }
    });
});
</script>
<style>


                    input[type=text] {
                        width: 190px;
                        height:44px;
                        box-sizing: border-box;
                        border: 2px solid #ccc;
                        border-radius: 4px;
                        font-size: 16px;
                        background-color: white;
                        background-repeat: no-repeat;
                        padding: 12px 20px 8px 45px;
                        -webkit-transition: width 0.4s ease-in-out;
                        transition: width 0.4s ease-in-out;
                    }
                    input[type=text]:focus {
                        width: 45%;
                    }
                    .card {
                        
                        transition: 0.3s;
                        width:55%;
                        border-radius: 50px;
                   background-color: white;}
                    h1{
                        
                        font-family: calibri;
                        font-style: bold;
                        font-size: 30px;
                    }
                </style>
    </head>
               <body><center><br><br><br><br><br><div  style="box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);background-color: #fff;width: 85%; height: 1000px"><?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>
                        <center>  
                            <div class="card" align="center"> <br>
                                <h1> Department Wise Monthly Report</h1>
                                <form method="get" action="depmonthreportpdf.php">
                                        <center><image src="image/report3.png" width="120px" height="120px"/></center><br><br>
                                        <input  style="background-image:url(image/r.png);" type="text" class="date-picker" placeholder="    Date..." name="month" required>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        
                                        
                                        
                                        
                                        
                                        
                                        <label><select class="sel" name="dep" required>
                                                <option class="opt" value="">Select</option>
                                                <option class="opt" value="CSE">CSE</option>
                                                <option class="opt" value="ECE">ECE</option>
                                                <option class="opt" value="EIE" >EIE</option>
                                                <option class="opt" value="PT" >PT</option>
                                                <option class="opt" value="IT">IT</option>
                                                <option class="opt" value="BT">BT</option>
                                                <option class="opt" value="EEE">EEE</option>
                                                <option class="opt" value="MECH" >MECH</option>
                                                <option class="opt" value="CIVIL">CIVIL</option>
                                                <option class="opt" value="MTR">MTR</option>
                                                <option class="opt" value="SS">SS</option>
                                                <option class="opt" value="Maths" >Maths</option>
                                                <option class="opt" value="Physics" >Physics</option>
                                                <option class="opt" value="Chemistry">Chemistry</option>
                                                <option class="opt" value="English">English</option>
                                                <option class="opt" value="Placement" >Placement</option>
                                                <option class="opt" value="Fine Arts" >Fine Arts</option>
                                                <option class="opt" value="Tech Beats">Tech Beats</option>
                                                <option class="opt" value="Tech Band">Tech Band</option>
                                                <option class="opt" value="NSS">NSS</option>
                                                <option class="opt" value="NCC" >NCC</option>
                                                <option class="opt" value="YRC" >YRC</option>
                                                <option class="opt" value="RRC">RRC</option>
                                                <option class="opt" value="Rotract" >Rotract</option>
                                                <option class="opt" value="Sports">Sports</option>
                              </select>
                                    </label><br><br>
                                        <button class="button" name="showme">Show Me</button>      
                                    </form><br>
                            </div>
                        </center>
                   </div>
        </body>
</html>

