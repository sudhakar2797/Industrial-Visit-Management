                      <?php     if (session_status() == PHP_SESSION_NONE) {session_start();}?>

<?php
$error="";
if(isset($_POST['send'])){
              
                $subject = " IV Query ";
                $message = "
                <html>
        <body style='width: 800px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 800px; height:100px;'><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'><br>QUERY<br><br><br>
                </div>
                        <pre style=' font-size:20px;font-family:calibre;'>   
    Sender Name                              :     ".$_POST['ccon']." 
    
    Query                                          :     ".$_POST['query']."

    Mail ID                                        :     ".$_POST['cemail']."              </pre>
      
        </body>
</html>";
                require 'config.php';
                $headers  = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                $result=mail($cto,$subject, $message, $headers); 
                if ($result) {
              $error= "Successfully Send";
                }else{
               $error= "Please Try Again";
                }
    
               }
    
?>
<!DOCTYPE html>
<html>
    <head><link href="css/styles.css">
         <title>Login & Sign Up Interface</title>
      <link rel="stylesheet" href="css/login.css">

        <style>.card {
    transition: 0.3s;
    border-radius: 5px;
}

</style></head>
    <body><center><br><br><br><br><br><div class="card" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1000px"><?php include 'home/header.php'; ?><br><?php include 'home/welcome.php';?><br><br><br><br><br><br><br>
            
                          <?php if(!empty($_SESSION['msg'])){?>
            <link href="css/alert.css" rel="stylesheet">
                                        <div class="alert" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $_SESSION['msg'];?>
                                     </div><?php }?>
<?php if($error!=""){?>
                        <link href="css/alert.css" rel="stylesheet">
<div class="alert success">
  <span class="closebtn">&times;</span>  
<?php echo $error?></div><?php }?>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script>
            
            
            
            <div class="body">
            <div class="panel">
  <ul id="menu" class="panel__menu">
    <hr/>
    <li id="signIn"> <a href="#">Login</a></li>
    <li id="signUp"><a href="#">Contact Us</a></li>
  </ul>
  <div class="panel__wrap">
    <div id="signInBox" class="panel__box active">
        <form action="checklogin.php" method="post">
                                  
                                     
                                     

      <label>User ID
          <input type="input" name="username" placeholder="User ID" required/>
      </label>
      <label>Password
          <input type="password" name="password" placeholder="Password" required/>
      </label>
                      <button name="login" >login</button>
    </form></div>

    <div id="signUpBox" class="panel__box">
        <form action="login.php" method="post">
        <label>E-Mail ID
            <input type="email" name="cemail" placeholder="Email ID" required />
      </label>
        <label>Name & Department
            <input type="input" name="ccon" placeholder=" Name & Department" required/>
      </label>
            <label>Query<br>

      <textarea placeholder="Type your message here...." name="query"  required></textarea>      </label>
            <button name="send"/>Send</button>
</form></div>    
  </div>
</div>
                                      <?php if(!empty($_SESSION['msg'])){  unset($_SESSION['msg']);}?>

    <script src="jq/index.js"></script>
        </div><br><br><?php include 'home/footer.php';?></div></center></body>  
</html>







