

<?php $merror;
if(isset($_POST['update'])){
    
$send=$_POST['id'];
    require 'dbconnect.php';
    $sql6="UPDATE faculty SET reportstatus='Review Completed' WHERE id='$send' ";
                                if($conn->query($sql6)){
                                    $merror="Successfully Updated";
                                }else{
                                    $merror="Not Updated Please Try Again";
                                }
    
    
    
    
}



?>

    

<!DOCTYPE html>
<html>
    <head><link href="css/styles.css">
        <style>.card {
    transition: 0.3s;
    border-radius: 5px;
}
</style></head>
    <body><br><br><br><br><br>
        
        <div align="center">
            
            
            <div class="card" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1000px">
                <?php include 'home/header.php'; ?><br><?php include ('home/menu.php');?><br><br><br><br>
<?php if(!empty($merror)){?>
            <link href="css/alert.css" rel="stylesheet">
                                        <div class="alert info" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $merror;?>
                                     </div><?php }?>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script>
        <link rel="stylesheet" type="text/css" media="all" href="css/app.css">
            
        <a href="review.php"><button class="butt"><span><< BACK TO &nbsp;</span></button></a><br><br>
              
        <br><br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
        <br><br>
        
        
        
        
        
        <?php include 'home/footer.php';?></div></div></body>  
</html> 