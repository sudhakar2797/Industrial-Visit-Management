<!DOCTYPE html>
<html>
    <head>
 
        <link rel="stylesheet" href="jq/jquery-ui.css">
        <script src="jq/jquery.js"></script>
        <script src="jq/jquery-ui.js"></script>
            <script>
                $( function(){
                $( "#datepicker" ).datepicker();
                $( "#format" ).on( "change", function() {
                $( "#datepicker" ).datepicker( "option", "dateFormat", $( this ).val() );
                });
                });
                $( function() {
                $( "#datepicker1" ).datepicker();
                $( "#format" ).on( "change", function() {
                $( "#datepicker1" ).datepicker( "option", "dateFormat", $( this ).val() );
                });
                });
            </script>
            <style>.ca {
    transition: 0.3s;
    border-radius: 5px;
}
.h4{color:black;
font-style:bold;
text-transform: capitalize;
    font-family: calibri;}
body{
    text-transform: capitalize;
}
</style>
        <link rel="stylesheet" type="text/css" media="all" href="css/styles.css">
       
        <?php if (session_status() == PHP_SESSION_NONE) {session_start();require 'dbconnect.php';}?>
        <?php 
                            
                            $id=$_SESSION['log'];
                            $sql = "SELECT * FROM  staffdetails  WHERE  StaffId='$id'";
                            $result = $conn->query($sql);
                                if($result->num_rows >0){
                                    while($row = $result->fetch_assoc()){
                                        $_SESSION['name']=$row['StaffName'];
                                        $_SESSION['desig']=$row['Designation'];
                                        $dep=$row['DepartmentId'];
                                        $_SESSION['depid']=$row['DepartmentId'];
                                        $_SESSION['mobile']=$row['ContactNo'];
                                        $_SESSION['email']=$row['EmailId'];
                                                                        }
                                                         }               
                            $sql = "SELECT * FROM  deptmaster  WHERE  id='$dep'";
                            $result = $conn->query($sql);
                                if ($result->num_rows >0){
                                    while($row = $result->fetch_assoc()){
                                        $_SESSION['dep']=$row['name']; }
                                                         }
        ?>
    </head>
   
           <body>
               <div class="ca" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);height:1500px  ;position:absolute;left:110px;top:100px ">
                   <pre></pre>
                   <center>
                       <?php include 'home/header.php'; ?>
                       <?php include 'home/menu.php';?>
                    </center><br><br>
                    
                          <?php if(!empty($_SESSION['msg'])){?>
                    <style>
                        .alert {
                            padding: 20px;
                            background-color: #f44336;
                            color: white;
                            opacity: 1;
                            transition: opacity 0.6s;
                            margin-bottom: 15px;
                            width: 50%;
                            border-radius: 20px;
                            position: absolute;
                            top:185px;
                            left: 100px;
                        }
                        
                    </style>
                    <link href="css/alert.css" rel="stylesheet">
                            <center>    
                                <div class="alert warning" style="width:50%;">
                                    <span class="closebtn">&times;</span>  
                                       <?php  echo  $_SESSION['msg'];?>
                                </div>
                            </center><?php }?>
                    <script>
                        var close = document.getElementsByClassName("closebtn");
                        var i;

                        for (i = 0; i < close.length; i++) {
                            close[i].onclick = function(){
                                var div = this.parentElement;
                                div.style.opacity = "0";
                                setTimeout(function(){ div.style.display = "none"; }, 600);
                            }
                        }
                    </script> 
        <div class="bod"> 
	<div class="p3">
        <div id="wrapper">
            <h1 style="color:white; font-family:calibri; text-align: center;font-size: 40px">Faculty Industrial Visit Approval Form</h1>
                <form name="form1" method="post" action="checkindex.php" >
                    <div class="col-1">
                      <label>Faculty Name<h4 class="h4"><?php echo $_SESSION['name'];?></h4></label>
                    </div>
                    <div class="col-2">
                        <label>Designation<h4 class="h4"><?php echo $_SESSION['desig'];?></h4></label>
                    </div>
                    <div class="col-2">
                        <label>Department<h4 class="h4"><?php echo $_SESSION['dep'];?></h4></label>
                    </div>
                    
                     <div class="col-2">
                        <label>E-mail Id<h4 class="h4"><?php echo $_SESSION['email'];?></h4></label>
                    </div>
                    
                    <div class="col-2">
                        <label> Mobile Number<h4 class="h4"><?php echo $_SESSION['mobile'];?></h4></label>
                    </div>
                    <div class="col-1">
                        <label>Name of the Industry *<input placeholder="Name of the Industry " name="noi" required></label>
                    </div> 
                 
                    <div class="col-2">
                        <label>Nature of the Industry *<input placeholder="Nature of the Industry " name="nri" required></label>
                    </div>
                
                    <div class="col-2">
                        <label>Address of the industry *<input placeholder="Address of the Industry"  name="aoi" required></label>
                    </div>
               
                    <div class="col-2">
                        <label>City *<input placeholder="City"  name="city" required></label>
                    </div>
                    
                    <div class="col-2">
                        <label>E-Mail ID / Website Address *<input  placeholder="E-Mail ID / Website Address"  name="iemail" required></label>
                    </div>
                    
                    <div class="col-2">
                        <label>Date of Visit *<input id="datepicker1" placeholder="Date of Visit"  name="dot" required></label>
                    </div>
                     
                     <div class="col-2">
                         <label>Duration of Visiting in days *<input placeholder="Number of Days Required To Visit"  name="dov" required></label>
                    </div>
                    
                    <div class="col-2">
                        <label>Contact  Person *<input placeholder="Contact Person Name" name="conper" required></label>
                    </div>
                   
                    <div class="col-2">
                        <label>Contact  Person Mobile Number *<input placeholder="Contact Person Mobile Number"  name="conperno"required></label>
                    </div>
                    <div class="col-1">
                        <label>remarks *<input placeholder="Remarks About  IV"  name="remark" required></label>
                    </div>
                    <div class="col-submit">
                        <button class="submitbtn" name="mainsubmit" value="Submit Form">Submit Form</button>
                    </div>
                </form><?php if(!empty($_SESSION['msg'])){  unset($_SESSION['msg']);}?>
        </div></div></div>
    
    </div></body>
</html> 