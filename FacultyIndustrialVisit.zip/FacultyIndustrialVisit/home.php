<!DOCTYPE html>
<html>
    <head><link href="css/styles.css">
        <style>.card {
    transition: 0.3s;
    border-radius: 5px;
}.chi {
    float: right;
    margin-left: 0px;
    display: inline-block;
    padding: 0 25px;
    height: 50px;
    font-size: 14px;
    line-height: 50px;
    border-radius: 25px;
    background-color: #f1eef1;
}

.chi img {
    float:right;
    margin: 0 -25px 0 10px ;
    height: 50px;
    width: 50px;
    border-radius: 50%;
}

.closebt {
    padding-right: 10px;
    color: #888;
    font-weight: bold;
    float: left;
    font-size: 20px;
    cursor: pointer;
}

.closebt:hover {
    color: #000;
}
.chip {
    float: left;
        margin-left:0px;
    display: inline-block;
    padding: 0 25px;
    height: 50px;
    font-size: 14px;
    line-height: 50px;
    border-radius: 25px;
    background-color: #f1eef1;
}

.chip img {
    float: left;
    margin: 0 10px 0 -25px;
    height: 50px;
    width: 50px;
    border-radius: 50%;
}

.closebtn {
    padding-left: 10px;
    color: #888;
    font-weight: bold;
    float: right;
    font-size: 20px;
    cursor: pointer;
}

.closebtn:hover {
    color: #000;
}
</style></head>
    <body><center><br><br><br><br><br><div class="card" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1400px"><?php include 'home/header.php';?><br><?php include 'home/menu.php';?><br><br><br>
 <div style="display: inline;">
                       
                        <div class="chip">
                            <img src="image/img_avatar2.png" alt="Person" width="96" height="96">
                            <img src="image/img_avatar.png" alt="Person" width="96" height="96">
                            <?php    
                                require 'dbconnect.php';
                                $so=$_SESSION['log'];
                                $query="SELECT * FROM staffdetails WHERE StaffId='$so'";
                                    $sql = $conn->query($query); 
                                        if($sql->num_rows >0) {
                                            while($row = $sql->fetch_assoc()) 
                                            {
                                                $name= $row['StaffName'];
                                            }
                                        }
                                echo "Hello!."." ".$name;
                            ?>
                            <span class="closebtn" onclick="this.parentElement.style.display='none'">&times;</span>
                        </div>
                    </div> <div class="chi">
                            <?php
                                date_default_timezone_set('Asia/Calcutta');
                                $Hour = date('G');
                                if ( $Hour >= 5 && $Hour <= 11 ) {
                                    echo "Good Morning";
                                } else if ( $Hour >= 12 && $Hour <= 18 ) {
                                    echo "Good Afternoon";
                                } else if ( $Hour >= 19 || $Hour <= 4 ) {
                                    echo "Good Evening";
                                }
                            ?>
                            <span class="closebt" onclick="this.parentElement.style.display='none'">&times;</span>
                            <img src="image/img_avatar.png" alt="Person" width="96" height="96">
                            <img src="image/img_avatar2.png" alt="Person" width="96" height="96">
                        </div><br><br>
        <img src="image/home.png"width=200px" height="200px" >
        <style> p{
            text-align: justify;
}</style>
        <br><h2 style="font-family: calibri;color:#357ae8;font-size: 35px">Faculty Industrial Visit</h2>
<h3><div align="left" style="word-break: normal;color:black;margin-left: 100px;font-size: 18px;margin-right: 100px">
        <h1 style="font-size: 25px"><b><center>The Functions of Industry-Institute Interaction Cell</center></b></h1>
        <img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To give industrial exposure to Faculty members and students, thus enabling them to tune their knowledge to cope with the industrial culture</p><br>
        <img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To assist the Departments in organizing workshops, conferences and symposia with joint participation of the   industries</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Encouraging Engineers from industries to visit institution to deliver lectures</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Participation of experts from industries, in curriculum development</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To organize industrial visits for Faculty members and students</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To encourage Faculty members to use their expertise in solving the problems faced by the industries, thus creating opportunity for consultancy</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Industrial testing by Faculty and technician at site, or in laboratory</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To organize in-plant training for the students</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To identify the areas for executive development programmes in the areas of recent technological advances</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To assist the Departments in establishing rapport with industries for taking up mini projects and projects</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To coordinate/ identify industrial partners for proposing ‘Centre for Excellence’.</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To strengthen Alumni relations</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To assist the Training and Placement Division</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Visit of industry executives and practicing engineers to the institute for seeing research work and laboratories</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Memorandum of Understanding between the institute and industries to bring the two sides emotionally and strategically closer</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Visiting faculty from industries</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">R&D Laboratories sponsored by industries at the institute</p><br>
    
     <?php include 'home/footer.php';?>
       
    
    </div></h3><br><br>
        
        
        
        
        
        
        
        
        
        
        
       </div></center></body>  
</html> 