        <?php if (session_status() == PHP_SESSION_NONE) {session_start();}?>
<!DOCTYPE html>
<html>
    <head><link href="css/styles.css">
        <style>.card {
    transition: 0.3s;
    border-radius: 5px;
}
                button::-moz-focus-inner {
                    border: 0;
                }
                input[type=submit]::-moz-focus-inner {
                    border: 0;
                }
                .card {
                    transition: 0.3s;
                    width:50%;
                    border-top-left-radius:  150px;
                    border-bottom-right-radius: 150px;
                }
                .card:hover {
                    box-shadow: 0 0 10px rgba(0,0,0,0.6);
                    -moz-box-shadow: 0 0 10px rgba(0,0,0,0.6);
                    -webkit-box-shadow: 0 0 10px rgba(0,0,0,0.6);
                    -o-box-shadow: 0 0 10px rgba(0,0,0,0.6);
                }
                button.accordion {
                    background-color: #eee;
                    color: #444;
                    cursor: pointer;
                    padding: 18px;
                    width: 70%;
                    border: none;
                    text-align: center;
                    outline: none;
                    font-size: 15px;
                    transition: 0.4s;
                }
                button.accordion.active, button.accordion:hover {
                    background-color: #ddd;
                }
                button.accordion:after {
                    content: '\02795';
                    font-size: 13px;
                    color: #777;
                    float: right;
                    margin-left: 5px;
                }
                button.accordion.active:after {
                    content: "\2796";
                }
                div.panel {
                    padding: 0 18px;
                    background-color: white;
                    max-height: 0;
                    overflow: hidden;
                    transition: 0.6s ease-in-out;
                    opacity: 0;
                }
                div.panel.show {
                    opacity: 1;
                    max-height: 500px;  
                }
                h4{
                    color: crimson;
                    font-family: calibri;
                    font-size: 30px;
                    text-align: center;
                }
                .but {
                    border-radius: 4px;
                    background-color: #4d90fe;
                    border: none;
                    color: #FFFFFF;
                    text-align: center;
                    font-size: 16px;
                    padding: 10px;
                    width: 300px;
                    transition: all 0.5s;
                    cursor: pointer;
                    margin: 5px;
                }
                .but span0 {
                    cursor: pointer;
                    display: inline-block;
                    position: relative;
                    transition: 0.5s;
                }
                span0:after {
                    content: ' Library';
                    position: absolute;
                    opacity: 0;
                    top: 0;
                    right: -20px;
                    transition: 0.5s;
                }
                .but:hover span0 {
                    padding-right: 55px;
                }
                .but:hover span0:after {
                    opacity: 1;
                    right: 0;
                }
                .but span1 {
                    cursor: pointer;
                    display: inline-block;
                    position: relative;
                    transition: 0.5s;
                }
                span1:after {
                    content: ' To Faculty';
                    position: absolute;
                    opacity: 0;
                    top: 0;
                    right: -20px;
                    transition: 0.5s;
                }
                .but:hover span1 {
                    padding-right: 80px;
                }
                .but:hover span1:after {
                    opacity: 1;
                    right: 0;
                }
                .but:hover{
                    background-color: #0000CC;
                }
                .but span6 {
                    cursor: pointer;
                    display: inline-block;
                    position: relative;
                    transition: 0.5s;
                }
                span6:after {
                    content: ' Report';
                    position: absolute;
                    opacity: 0;
                    top: 0;
                    right: -20px;
                    transition: 0.5s;
                }
                .but:hover span6 {
                    padding-right: 55px;
                }
                .but:hover span6:after {
                    opacity: 1;
                    right: 0;
                }
</style></head>
    <body><center><br><br><br><br><br><div  style="background-color: #fff;width: 85%; height: 2000px;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);">
        <?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>

           
                    <div class="card"><br>
                        <h1 style="color:black; font-family: calibri;font-style: bold">Admin Panel</h1>
                        <image src="image/admin.png" width="100px" height="100px"/><br><br>
                       
                        <button class="accordion">Mail Alert</button>
                            <div class="panel">
                                <h4>Mail Alert</h4>
                                <a href="mailalert.php"><button class="but"><span1>Mail Alert</span1></button></a><br>
                                <br><br></div>
                        <button class="accordion">Review Status</button>
                            <div class="panel">
                                <h4>Mail Alert</h4>
                                <a href="review.php"><button class="but"><span1>Review Status Update</span1></button></a><br>
                                <br><br></div>
                        <button class="accordion">Report</button>
                            <div class="panel">
                                <h4>Industrial Visit Report</h4>
                                <a href="depmonth.php"><button class="but"><span6>Department Wise Month</span6></button></a><br>
                                <a href="depstatus.php"><button class="but"><span6>Department Wise Status</span6></button></a><br>
                                <a href="depyear.php"><button class="but"><span6>Department Wise Year</span6></button></a><br>
                                <a href="year.php"><button class="but"><span6>college Year</span6></button></a><br>
                                <a href="semreport.php"><button class="but"><span6>college Semester</span6></button></a><br>
<br><br><br></div>
                        
                       <br><br><br><br>
                        <script>
                            var acc = document.getElementsByClassName("accordion");
                            var i;
                            for (i = 0; i < acc.length; i++) {
                                acc[i].onclick = function(){
                                    this.classList.toggle("active");
                                    this.nextElementSibling.classList.toggle("show");}
                            }
                        </script> 
                    </div> <?php include 'home/footer.php';?><br><br><br><br><br><br>
                </center>
              
           
        
        
        
        
        
        
        
        
        
       </div></center></body>  
</html> 