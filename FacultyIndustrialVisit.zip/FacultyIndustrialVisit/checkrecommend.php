<?php if (session_status() == PHP_SESSION_NONE) {session_start();}
    $id=$_SESSION['eid'];
    include('dbconnect.php');
        if (!empty($_POST['valid'])){
            $security=$_POST['valid'];
            $sql = "SELECT id FROM  faculty WHERE id='$id' AND security='$security'";
            $result = $conn->query($sql);
        
        if ($result->num_rows==0){
            $_SESSION['msg'] ="Please Enter Valid Authentication Code";
            header("location: recommend.php"); 
                                
        }elseif(isset($_POST['recommend'])) {
                $HODremark="HOD::".$_POST['req'];
                $sql = "UPDATE faculty SET hodrecommend='recommended' WHERE id='$id'";
                $sql1="update faculty set remark='$HODremark' WHERE id='$id'";
            if((mysqli_query($conn,$sql))&&(mysqli_query($conn,$sql1))){
                            
               
                                    $subject = "Industrial Visit Request [Recommended By HOD]";
                                    $did= $_SESSION['id'];
                                     require 'config.php';
                                     $approvedurl=$approvedurl."?id=$did";
$message="        
            
<html>
<head>
                <title>Faculty Industrial Visit</title>
            </head>
            <body style='width: 1000px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 1000px; height:100px;'><center><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'>Faculty Industrial Visit Approval Form Details</p></center>
                </div><pre style='style:bold; font-family:calibri; text-align: left;font-size: 20px;word-wrap:break-word;display:inline;'>
            Facultyname                :   ".$_SESSION['name']."

            Department                 :   ".$_SESSION['dep']."

            Industry Name             :   ".$_SESSION['noi']."

            Industry Address          :   ".$_SESSION['aoi']."

            Date Of Visit                :   ".$_SESSION['dot']."

            Contact Person            :   ".$_SESSION['conper']."

            Mobile No                    :   ".$_SESSION['conperno']."

            Remarks		   :   ".$_SESSION['remark']."

            HOD Recommendation Status    :   <h5 style='color:green;font-size:25px;text-align:center;display:inline;'>Recommended</h5>

            HODRemarks		   :   ".$_POST['req']."
                
            Authentication Code    :   <h5 style='color:red;font-size:25px;text-align:center;display:inline;'>".$security."</h5>
            
            Please Click Here To Recommend / Reject     :<br>   ".$approvedurl."</pre>
                   <pre>                                                    
                </body></html>";

                   
                 
                $headers  = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                
                
                    
                 	
                   require 'config.php';
                     
                    foreach($contacts as $contact){
                    $result=mail($contact,$subject, $message, $headers); 
                    }
                            
                    
                    
                    $to=$_SESSION['email'];
                            $subject = " Industrial Visit Request Is Recommended By HOD   ";
                            $message = "
                            <html>
        <body style='width: 1000px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 1000px; '><center><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'>IV Request Status</p></center>
                </div>        <pre style=' font-size:20px;font-family:calibre;'>   
    Faculty Name                              :     ".$_SESSION['name']." 
        
    Industry Name                             :     ".$_SESSION['noi']."

    Dean Recommendation Status    :     PENDING

    HOD  Recommendation Status    :     RECOMMMENDED               
                        </pre>
      
        </body></html>";
                            
                           
                 
                $headers  = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                
                
                            $result1=mail($to,$subject, $message, $headers); 
                                if (($result)&&($result1)) {
                                    header("location: rthankyou.php");
                                    }else{
                                    $_SESSION['msg'] = " Please Try Again";
                                    header("location: recommend.php"); 
                                         }
                                        }else{
                                    $_SESSION['msg'] = " Please Try Again";
                                    header("location: recommend.php"); 
                                        }
                                         
                                     }  
                            
                            
   //-------------------------------------------------------------------------------------------------------//   
   elseif(isset($_POST['notrecommend'])) {
        if (empty($_POST['req'])) {
             $_SESSION['msg'] ="Remark Is Required";
             header("location: recommend.php"); 
        }else{
            $remark="HOD::".$_POST['req'];
            $sql = "UPDATE faculty SET hodrecommend='not recommended' WHERE id='$id'";
            $sql1 = "UPDATE faculty SET remark='$remark' WHERE id='$id'";
            if((mysqli_query($conn,$sql))&&(mysqli_query($conn,$sql1))){
                   $to=$_SESSION['email'];
                $subject = " Industrial Visit Request Is Rejected By HOD ";
                $message = "
                <html>
        <body style='width: 1000px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 1000px; '><center><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'>IV Request Status</p></center>
                </div>

                        <pre style=' font-size:20px;font-family:calibre;'>   
    Faculty Name                              :     ".$_SESSION['name']." 
    
    Industry Name                             :     ".$_SESSION['noi']."

    HOD Recommendation Status    :     REJECTED

    Remarks                                       :     ".$_POST['req']. "
        
                        </pre>
      
        </body></html>";
                
                    
                    
                $headers  = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                
                
                $result=mail($to,$subject, $message, $headers); 
                if ($result) {
                
                    header("location: reject.php");
                }else{
                $_SESSION['msg'] = "Please Try Again";
                header("location: recommend.php"); 
                }
            }else{
                $_SESSION['msg'] = "Please Try Again";
                header("location: recommend.php"); 
                }
            }  
    }
    }else{$_SESSION['msg'] ="Please Enter Authentication Code";
             header("location: recommend.php"); 
         }
mysqli_close($conn);?>
        
        