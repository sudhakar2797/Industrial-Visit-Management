<?php if (session_status() == PHP_SESSION_NONE) {session_start();}?><!DOCTYPE html>
<html>
    <head><link href="css/styles.css">
        <style>.card {
                    transition: 0.3s;
                    width:50%;
                    border-top-right-radius:  20px;
                    border-bottom-left-radius: 20px;
                }
                .card:hover {
                    box-shadow: 0 0 10px rgba(0,0,0,0.6);
                    -moz-box-shadow: 0 0 10px rgba(0,0,0,0.6);
                    -webkit-box-shadow: 0 0 10px rgba(0,0,0,0.6);
                    -o-box-shadow: 0 0 10px rgba(0,0,0,0.6);
                }

button{
	color: #FFF;
	font-size: 0.9em;
	font-weight: 500;
	padding: 0.8em 2em;
	text-decoration: none;
	background: #f7d30b;
	text-transform:uppercase;
	-webkit-appearance:none;
	border-radius:1em;
	-webkit-border-radius:1em;
	-o-border-radius:1em;
	-moz-border-radius:1em;
	outline: none;
}
.login {
    width: 200px;
    overflow: hidden;
    background: #1e1e1e;
    border-radius: 6px;
    margin: 50px auto;
}
.login:hover{
width: 220px;
    box-shadow: 0px 0px 50px rgba(0,0,0,.8);

}

.login .titulo {
    height: 70px;
    width: 100px;
    padding-top: 13px;
    padding-bottom: 13px;
    font-size: 14px;
    text-align: center;
    color: #bfbfbf;
    background: #121212;
    border: #2d2d2d solid 1px;
    margin-bottom: 30px;
    border-top-right-radius: 6px;
    border-top-left-radius: 6px;
    font-family: Arial;
}

.login form {
    width: 200px;
    height: auto;
    overflow: hidden;
    margin-left: auto;
    margin-right: auto;
}


button::-moz-focus-inner {
  border: 0;
}

input[type=submit]::-moz-focus-inner {
  border: 0;
}

table {
    border-collapse: collapse;
    margin-bottom: 3em;
    width: 100%;
    background: #fff;
}
td, th {
    padding: 0.75em 1.5em;
    text-align: left;
}
	
th {
    background-color: #9238ff;
    font-weight: bold;
    color: #fff;
    white-space: nowrap;
}
tbody th {
	background-color: #ff4572;
}

tbody tr:hover {
    background-color: rgba(0,09,166,.2);
}



</style></head>
    <body><center><br><br><br><br><br><div  style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1000px"><?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>
            <link href="css/mail.css" rel="stylesheet">

            
             <?php if(!empty($_SESSION['merror'])){?>
            <link href="css/alert.css" rel="stylesheet">
                                        <div class="alert info" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $_SESSION['merror'];?>
                                     </div><?php }?>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script>
            
            
<div class="wrap" style="width:25%">
                                    <div class="pricing-grid1">
					<div class="price-value" >
                                            <h2 style="font-family: calibri;"> Mail Alert</h2>
						
					</div>
                                        <div class="cart1" >
                                                        <form method="post" action="mailalert.php">
                                                            <button name="mail" >Show Me</button>
                                                            </form><?php if(!empty($_SESSION['merror'])){  unset($_SESSION['merror']);}?>

                                                    </div>
                                    </div>
				</div><br><br><br><br><br>


                                
                                
                                <center><div class="card"><br>
    <?php
                    if(isset($_POST['mail'])){
                        echo'<table>';
                            echo'<thead>';
                                echo'<tr>';
                                    echo'<th>Name</th>';
                                    echo'<th>Mail ID</th>';
                                echo'</tr>';
                            echo'</thead>';
                        echo'<tbody>';
                            require 'dbconnect.php'; 
                            $date=date('Y-m-d');
                            $query="SELECT * FROM faculty WHERE reportstatus ='pending' ";
                            $sql = $conn->query($query); 
                                if($sql->num_rows >0) {
                                    while($row = $sql->fetch_assoc()) 
                                    { $staffid=$row['StaffID'];
                                        $date1=$row['dateofvisit'];
                                        $date2=date('Y-m-d');
                                        $ts1 = strtotime($date1);
                                            $ts2 = strtotime($date2);

                                                    $seconds_diff = $ts2 - $ts1;
                                            $seconds_diff=$seconds_diff/(60*60*24);
                                             if($seconds_diff>=7){
                                                 $query1="SELECT * FROM staffdetails WHERE StaffId='$staffid' ";
                                        $sql1 = $conn->query($query1); 
                                            if($sql1->num_rows >0) {
                                              while($row1 = $sql1->fetch_assoc()) 
                                                {
                                                 
                                                    echo'<tr><td style="color:maroon"; class="user-name">'.$row1['StaffName'] .'</td><td style="color:indigo;" class="user-name">'.$row1['EmailId'] .'</td></tr>';
                                             }}else{
                                    echo'<tr ><td colspan="2" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Request Found</p></td></tr>';
                    }}
                                    }
                                    echo'<br><br><div  ><form action="send.php" method="post"><button name="send">Send</button><br><br></form></div>';
                                }else{
                                    echo'<tr ><td colspan="2" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Request Found</p></td></tr>';
                    }
                    mysqli_close($conn);}
                        echo'</tbody>';
                        echo'</table>';
?>          <br><br>  </div>
                            </center>
        
        
        
        
        
        
        



    
    
    
    
    </div>
        
  </center></body>  
</html> 

