<?php if (session_status() == PHP_SESSION_NONE) {session_start();}?>




<!DOCTYPE html>
<html>
    <head><link href="css/styles.css">
        <style>.card {
                    transition: 0.3s;
                    width:80%;
                    border-top-right-radius:  20px;
                    border-bottom-left-radius: 20px;
                }
                .card:hover {
                    box-shadow: 0 0 10px rgba(0,0,0,0.6);
                    -moz-box-shadow: 0 0 10px rgba(0,0,0,0.6);
                    -webkit-box-shadow: 0 0 10px rgba(0,0,0,0.6);
                    -o-box-shadow: 0 0 10px rgba(0,0,0,0.6);
                }

button{
	color: #FFF;
	font-size: 0.9em;
	font-weight: 500;
	padding: 0.8em 2em;
	text-decoration: none;
	background: #f7d30b;
	text-transform:uppercase;
	-webkit-appearance:none;
	border-radius:1em;
	-webkit-border-radius:1em;
	-o-border-radius:1em;
	-moz-border-radius:1em;
	outline: none;
}
.login {
    width: 200px;
    overflow: hidden;
    background: #1e1e1e;
    border-radius: 6px;
    margin: 50px auto;
}
.login:hover{
width: 220px;
    box-shadow: 0px 0px 50px rgba(0,0,0,.8);

}

.login .titulo {
    height: 70px;
    width: 100px;
    padding-top: 13px;
    padding-bottom: 13px;
    font-size: 14px;
    text-align: center;
    color: #bfbfbf;
    background: #121212;
    border: #2d2d2d solid 1px;
    margin-bottom: 30px;
    border-top-right-radius: 6px;
    border-top-left-radius: 6px;
    font-family: Arial;
}

.login form {
    width: 200px;
    height: auto;
    overflow: hidden;
    margin-left: auto;
    margin-right: auto;
}


button::-moz-focus-inner {
  border: 0;
}

input[type=submit]::-moz-focus-inner {
  border: 0;
}

table {
    border-collapse: collapse;
    margin-bottom: 3em;
    width: 100%;
    background: #fff;
}
td, th {
    padding: 0.75em 1.5em;
    text-align: left;
}
	
th {
    background-color: #9238ff;
    font-weight: bold;
    color: #fff;
    white-space: nowrap;
}
tbody th {
	background-color: #ff4572;
}

tbody tr:hover {
    background-color: rgba(0,09,166,.2);
}



</style></head>
    <body><center><br><br><br><br><br><div  style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1000px"><?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>

            
             <?php if(!empty($merror)){?>
            <link href="css/alert.css" rel="stylesheet">
                                        <div class="alert info" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $merror;?>
                                     </div><?php }?>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script>
            
            
            
            
            <section class="login">
    <div class="titulo"><h2 style="color:white">Status</h2></div>
    <form action="review.php" method="post" >
        <h3 style="color:white">
        <center><button name="mail" class="button" >Show Me</button></center>        <br>

    </form><?php if(!empty($merror)){  unset($merror);}?>
</section>





<center><div class="card"><br>
    <?php   $dep="";
                    if(isset($_POST['mail'])){
                        echo'<table>';
                            echo'<thead>';
                                echo'<tr>';
                                    echo'<th>Id</th>';
                                    echo'<th>Name</th>';
                                    echo'<th>Department</th>';
                                    echo'<th>Industry</th>';
                                    echo'<th>Status</th>';

                                echo'</tr>';
                            echo'</thead>';
                        echo'<tbody>';
                            require 'dbconnect.php'; 
                            $query="SELECT * FROM faculty WHERE reportstatus ='reportsubmitted' ";
                            $sql = $conn->query($query); 
                                if($sql->num_rows >0) {
                                    $sendid=$sql->num_rows;
                                    while($row = $sql->fetch_assoc()) 
                                    { $staffid=$row['StaffID'];
                                    $iid=$row['id'];
                                    $sql1="select industryname from industry where id ='$iid'";
                                    $result1=$conn->Query($sql1);
                                    if($result1->num_rows > 0){
                                    $row1 =$result1->fetch_assoc();
                                    $industry22=$row1['industryname'];    }
                                                 $query1="SELECT * FROM staffdetails WHERE StaffId='$staffid' ";
                                        $sql1 = $conn->query($query1); 
                                            if($sql1->num_rows >0) {
                                              while($row1 = $sql1->fetch_assoc()) 
                                                {
                                                 $depid=$row1['DepartmentId'];
                                                
                                                 $sql3 = "SELECT * FROM  deptmaster  WHERE  id='$depid'";
                            $result3 = $conn->query($sql3);
                                if ($result3->num_rows >0){
                                    while($row = $result3->fetch_assoc()){
                                        $dep=$row['name']; }
                                                         }?>
        <style>input[type="text"] {
    border: none;
    overflow: auto;
    outline: none;
    background-color: none;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
    width: 100px;
}</style>
                                                    <tr><form method="post" action="reviewupdate.php">
                                                        <td style="color:maroon"; class="user-name"><input type="text" name="id" value="<?php echo $iid?>" readonly></td>
                                                        <td style="color:maroon"; class="user-name"><?php echo $row1['StaffName']?></td>
                                                        <td style="color:indigo;" class="user-name"><?php echo $dep?></td>  
                                                        <td class="user-name"><?php echo $industry22?></td>
                                                        <td class="user-name"><button class="but" name="update"><span>Update&nbsp</span></button></td>
                                                    </form></tr>
                                            <?php }
                                             
                                                }else{
                                    echo'<tr ><td colspan="5" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Request Found</p></td></tr>';
                    }}
                                    
                                }else{
                                    echo'<tr ><td colspan="5" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Request Found</p></td></tr>';
                    }
                    mysqli_close($conn);}
                        echo'</tbody>';
                        echo'</table>';
?>          <br><br>  </div>
                            </center>
        
        
        
        
        
        
        



    
    
    
    
    </div>
        
  </center></body>  
</html> 

