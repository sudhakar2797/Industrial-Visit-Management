<!DOCTYPE html>
<html lang="en">
<head>
   <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <style>/* The Modal (background) */
        
 .but {
  border-radius: 4px;
  background-color: #357ae8;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 16px;
  padding: 10px;
  width: 190px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}
 
.but span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.but span:after {
  content: ' To Login';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.but:hover span {
  padding-right: 70px;
}

.but:hover span:after {
  opacity: 1;
  right: 0;
}


.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 10; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    
    position: relative;
    background-color: #fefefe;
    margin: auto;
    padding: 0;
    border: 1px solid #888;
    width: 40%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-animation-name: animatetop;
    -webkit-animation-duration: 0.4s;
    animation-name: animatetop;
    animation-duration: 0.4s
}

/* Add Animation */
@-webkit-keyframes animatetop {
    from {top:-300px; opacity:0} 
    to {top:0; opacity:1}
}

@keyframes animatetop {
    from {top:-300px; opacity:0}
    to {top:0; opacity:1}
}

/* The Close Button */
.cl {
    color: white;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.cl:hover,
.cl:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
.modal-header {
    padding: 2px 16px;
    background-color: #357ae8;
    color: white;
    text-transform: capitalize;
}

.modal-body {padding: 2px 16px;}

.modal-footer {
    padding: 2px 16px;
    background-color: #357ae8;
    color: white;
}</style>
   </head><!--/head-->
   <link href="/bootstrap.min.css" >
   <link href="/bootstrap.min.js" >
   <link href="/jquery.min.js" >
   
<body data-spy="scroll"  data-offset="0">
    <header id="header" role="banner">
        <div class="container">
            <div id="navbar" class="navbar navbar-default">
                <div class="navbar-brand"></div>
                    
                
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href=""><i ></i></a></li>
                        <li><a href="welcome.php">home</a></li>
                        <li id="myBtn"><a href="#">Apply</a></li>
                        <li id="myBtn1"><a href="#">Report</a></li>
                        <li id="myBtn2"><a href="#">About Us</a></li>
                        <li id="myBtn3"><a href="#">Help</a></li>
                        <li id="myBtn4"><a href="#">Status</a></li>
                        <li><a href="login.php">Contact Us</a></li>
                        <li><a href="login.php">Login</a></li>
                        <li class="active"><a href=""><i ></i></a></li>
                    </ul>
                </div>
                    
            </div>
                    
        </div>
    </header>

<div id="myModal" class="modal">
  <div class="modal-content">
    <div class="modal-header" >
      <span class="cl">x</span>
      <h2 style="color:white;font-size: 30px;font-family: calibri;">Faculty Industrial Visit</h2>
    </div>
    <div class="modal-body" align="center"><br>
        <img src="image/home.png"width=200px" height="200px" >
            <h5 style="color:black;font-family: calibri;font-size: 25px;style:bold;"> Please <b style="display:inline; color:crimson;">Login</b> First.....
            <a href="login.php"><button class="but"><span>Click Here</span></button></a></h5>
    </div>
    <div class="modal-footer" alifn="center">
        <center><h3 style="color:white">!!!.....Welcome To All.....!!!</h3></center>
    </div>
  </div>
</div>
         
</body>
<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");
var btn1 = document.getElementById("myBtn1");
var btn2 = document.getElementById("myBtn2");
var btn3 = document.getElementById("myBtn3");
var btn4 = document.getElementById("myBtn4");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("cl")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks the button, open the modal 
btn1.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks the button, open the modal 
btn2.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks the button, open the modal 
btn3.onclick = function() {
    modal.style.display = "block";
}


// When the user clicks the button, open the modal 
btn4.onclick = function() {
    modal.style.display = "block";
}



// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
  
</html>