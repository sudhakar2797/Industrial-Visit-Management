<?php
echo "<p><center>Copyright &copy; 1998 - " . date("Y") . " Kamaraj  of College Engineering & Technology</center></p>";
?>
