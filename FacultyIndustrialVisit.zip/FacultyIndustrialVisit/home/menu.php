                        <?php     if (session_status() == PHP_SESSION_NONE) {session_start();}?>

<!DOCTYPE html>
<html lang="en">
<head>
   <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
   </head><!--/head-->

   <body data-spy="scroll"  data-offset="0" >
       <header id="header" role="banner">
        <div class="container" >
            <div id="navbar" class="navbar navbar-default">
                    
                
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li style="margin-left: 40px" class="activ"><a href=""><i ></i></a></li>
                        <li><a href="home.php">Home</a></li>
                        <li><a href="index1.php">Apply</a></li>
                        <li><a href="report.php">Report</a></li>
                        <li><a href="search.php">Search</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="statusboard.php">Status</a></li>
                        <li><a href="help.php">Help</a></li>
                       <?php require 'config.php';
                        if( $_SESSION['log']==$ad){?>
                       <li><a href="admin.php">Admin</a></li><?php }?>
                       <li><a href="logout.php">Logout</a></li>
                          <li class="activ"><a href=""><i ></i></a></li>

                    </ul>
                </div>
                    
            </div>
                    
        </div>
        
    </header><!--/#header-->
       
               
</body>
</html>