<!DOCTYPE html>
<html>
    <head><link href="css/styles.css">
        <style>.card {
    transition: 0.3s;
    border-radius: 5px;
            }
            .statusboard {
box-shadow: 0 0 10px rgba(0,0,0,0.6);
    -moz-box-shadow: 0 0 10px rgba(0,0,0,0.6);
    -webkit-box-shadow: 0 0 10px rgba(0,0,0,0.6);
    -o-box-shadow: 0 0 10px rgba(0,0,0,0.6);


    width: 70%;
    height: 50%;
    
}
 
</style></head>
    <body><center><br><br><br><br><br><div class="card" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1000px"><?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>
            <div class="statusboard"><br>
                <center><img src="image/status.png" width="100px" height="110px">
            
                  <style>


.checkout-wrap {
  color: #444;
  font-family: 'PT Sans Caption', sans-serif;
  margin: 40px auto;
  max-width: 800px;
  position: relative;
}

ul.checkout-bar li {
  color: #ccc;
  display: block;
  font-size: 16px;
  font-weight: 600;
  padding: 14px 20px 14px 80px;
  position: relative;
}
ul.checkout-bar li:before {
  -webkit-box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
  box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
  background: #ddd;
  border: 2px solid #FFF;
  border-radius: 50%;
  color: #fff;
  font-size: 16px;
  font-weight: 700;
  left: 20px;
  line-height: 37px;
  height: 35px;
  position: absolute;
  text-align: center;
  text-shadow: 1px 1px rgba(0, 0, 0, 0.2);
  top: 4px;
  width: 35px;
  z-index: 999;
}
ul.checkout-bar li.active {
  color: #8bc53f;
  font-weight: bold;
}
ul.checkout-bar li.active:before {
  background: #8bc53f;
  z-index: 99999;
}

ul.checkout-bar li.visited:before {
  background: #57aed1;
  z-index: 99999;
}

ul.checkout-bar li.complete:before {
  background: #8bc53f;
  z-index: 99999;
}
ul.checkout-bar li.reject:before {
    background: #ff3333;
  z-index: 99999;
}
ul.checkout-bar li:nth-child(1):before {
  content: "1";
}
ul.checkout-bar li:nth-child(2):before {
  content: "2";
}
ul.checkout-bar li:nth-child(3):before {
  content: "3";
}
ul.checkout-bar li:nth-child(4):before {
  content: "4";
}
ul.checkout-bar li:nth-child(5):before {
  content: "5";
}


@media all and (min-width: 800px) {
  .checkout-bar li.active:after {
    -webkit-animation: myanimation 3s 0;
    background-size: 35px 35px;
    background-color: #8bc53f;
    background-image: -webkit-linear-gradient(-45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -moz-linear-gradient(-45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    -webkit-box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    content: "";
    height: 15px;
    width: 100%;
    left: 50%;
    position: absolute;
    top: -50px;
    z-index: 0;
  }

  .checkout-wrap {
    margin: 80px auto;
  }

  ul.checkout-bar {
    -webkit-box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    background-size: 35px 35px;
    background-color: #EcEcEc;
    background-image: -webkit-linear-gradient(-45deg, rgba(255, 255, 255, 0.4) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.4) 50%, rgba(255, 255, 255, 0.4) 75%, transparent 75%, transparent);
    background-image: -moz-linear-gradient(-45deg, rgba(255, 255, 255, 0.4) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.4) 50%, rgba(255, 255, 255, 0.4) 75%, transparent 75%, transparent);
    border-radius: 15px;
    height: 15px;
    margin: 0 auto;
    padding: 0;
    position: absolute;
    width: 100%;
  }
  ul.checkout-bar:before {
    background-size: 35px 35px;
    background-color: #57aed1;
    background-image: -webkit-linear-gradient(-45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -moz-linear-gradient(-45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    -webkit-box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    border-radius: 15px;
    content: " ";
    height: 15px;
    left: 0;
    position: absolute;
    width: 10%;
  }
  ul.checkout-bar li {
    display: inline-block;
    margin: 50px 0 0;
    padding: 0;
    text-align: center;
    width: 19%;
  }
  ul.checkout-bar li:before {
    height: 45px;
    left: 40%;
    line-height: 45px;
    position: absolute;
    top: -65px;
    width: 45px;
    z-index: 99;
  }
  ul.checkout-bar li.visited {
    background: none;
  }
  ul.checkout-bar li.visited:after {
    background-size: 35px 35px;
    background-color: #57aed1;
    background-image: -webkit-linear-gradient(-45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -moz-linear-gradient(-45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    -webkit-box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    content: "";
    height: 15px;
    left: 50%;
    position: absolute;
    top: -50px;
    width: 100%;
    z-index: 99;
  }
ul.checkout-bar li.complete {
    background: none;
  }
  ul.checkout-bar li.complete:after {
    background-size: 35px 35px;
    background-color: #57aed1;
    background-image: -webkit-linear-gradient(-45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -moz-linear-gradient(-45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    -webkit-box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    content: "";
    height: 15px;
    left: 50%;
    position: absolute;
    top: -50px;
    width: 57%;
    border-bottom-right-radius: 10px;
        border-top-right-radius: 10px;

    z-index: 99;
  }
ul.checkout-bar li.reject {
    background: none;
  }
  ul.checkout-bar li.reject:after {
    background-size: 35px 35px;
    background-color: #ff3333;
    background-image: -webkit-linear-gradient(-45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    background-image: -moz-linear-gradient(-45deg, rgba(255, 255, 255, 0.2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.2) 50%, rgba(255, 255, 255, 0.2) 75%, transparent 75%, transparent);
    -webkit-box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    box-shadow: inset 2px 2px 2px 0px rgba(0, 0, 0, 0.2);
    content: "";
    height: 15px;
    left: 50%;
    position: absolute;
    top: -50px;
    width: 100%;
    z-index: 99;
      }
}
</style>
  
</head>

<body>

    <?php if (session_status() == PHP_SESSION_NONE) {session_start();}
    $status=$hodrecommend=$deanapproval=$reportstatus="";
    require 'dbconnect.php';
    $id = $_SESSION['log'];
    $sql="select hodrecommend,deanapproval,reportstatus,id from faculty where StaffId ='$id'";
    $result=$conn->Query($sql);
    if($result->num_rows > 0){
    while($row =$result->fetch_assoc()){
        $deanapproval=$row['deanapproval'];
        $hodrecommend=$row['hodrecommend'];
        $reportstatus=$row['reportstatus'];
        $iid=$row['id'];
    }
     $sql1="select industryname from industry where id ='$iid'";
    $result1=$conn->Query($sql1);
    if($result1->num_rows > 0){
    $row1 =$result1->fetch_assoc();
    $industry=$row1['industryname'];
    
    }
    
    }

     if(($reportstatus=="pending")&&($hodrecommend=="pending")){
         $status="pending";
     }
     if (($reportstatus=="pending")&&($hodrecommend=="recommended")) {
        $status="recommended";
    }
    if (($reportstatus=="pending")&&($hodrecommend=="not recommended")) {
        $status="not recommended";
    }
    if (($deanapproval=="approved")&&($hodrecommend=="recommended")) {
        $status="approved";
    }
    if (($deanapproval=="not approved")&&($hodrecommend=="recommended")) {
        $status="not approved";
    }
    if (($deanapproval=="approved")&&($reportstatus=="reportsubmitted")) {
        $status="reportsubmitted";
    }
    if (($deanapproval=="approved")&&($reportstatus=="Review Completed")) {
        $status="review completed";
    }
   
         mysqli_close($conn);

    ?>
    
    
    
<h4 style="font-size: 20px;color: black;font-style: bold;">Industry Name &nbsp;:&nbsp;&nbsp;
    <?php if(isset($industry)){echo $industry;}else{echo "NO";}?></h4>
    
    
    
    
<div class="checkout-wrap">
  <ul class="checkout-bar">
      
      <?php 
if($status==""){ ?>
      <li class="next">Request</li>
    
    <li class="next">Recommend</li>
    
    <li class="next">Approval</li>
    
    <li class="next">Report</li>
    
    <li class="next">Review</li>
  <?php } ?>
    
    
    
    
<?php 

if($status=="pending"){ ?>
      <li class="visited " style="color:#57aed1">Request</li>
    
    <li class="next">Recommend</li>
    
    <li class="next">Approval</li>
    
    <li class="next">Report</li>
    
    <li class="next">Review</li>
  <?php } ?>
    <?php
    
if($status=="recommended"){ ?>
      <li class="active" style="color:#57aed1">Request</li>
    
    <li class="active">Recommend</li>
    
    <li class="next">Approval</li>
    
    <li class="next">Report</li>
    
    <li class="next">Review</li>
  <?php } ?>
    
    <?php 
if($status=="not recommended"){ ?>
      <li class="visited" style="color:#57aed1">Request</li>
    
      <li class="reject" style="color:#ff3333">Recommend</li>
    
    <li class="next">Approval</li>
    
    <li class="next">Report</li>
    
    <li class="next">Review</li>
  <?php } ?>
    
    
    
    
    
    <?php
    
if($status=="approved"){ ?>
      <li class="active " style="color:#57aed1">Request</li>
    
    <li class="active">Recommend</li>
    
    <li class="active">Approval</li>
    
    <li class="next">Report</li>
    
    <li class="next">Review</li>
  <?php } ?>
    
    <?php 
if($status=="not approved"){ ?>
      <li class="active" style="color:#57aed1">Request</li>
    
    <li class="active">Recommend</li>
    
    <li class="reject" style="color:#ff3333">Approval</li>
    
    <li class="next">Report</li>
    
    <li class="next">Review</li>
  <?php } ?>
    
    
    
    
    <?php
    
if($status=="reportsubmitted"){ ?>
      <li class="active" style="color:#57aed1">Request</li>
    
    <li class="active">Recommend</li>
    
    <li class="active">Approval</li>
    
    <li class="active">Report</li>
    
    <li class="next" >Review</li>
  <?php } ?>
    
    <?php
    
if($status=="review completed"){ ?>
      <li class="active" style="color:#57aed1">Request</li>
    
    <li class="active">Recommend</li>
    
    <li class="active">Approval</li>
    
    <li class="active">Report</li>
    
    <li class="complete" style="color:#57aed1">Review</li>
  <?php } ?>
    
    <br><br><br><br>
    <img src="image/waiting.png" width="20px" height="20px"><h4 style="display:inline;font-size: 23px;color: black;font-style: bold;">&nbsp;&nbsp;&nbsp;Waiting&nbsp;&nbsp;</h4>
    <img src="image/success.png" width="20px" height="20px"><h4 style="display:inline;font-size: 23px;color: black;font-style: bold;">&nbsp;&nbsp;&nbsp;Success&nbsp;&nbsp;</h4>
    <img src="image/reject.png" width="20px" height="20px"><h4 style="display:inline;font-size: 23px;color: black;font-style: bold;">&nbsp;&nbsp;&nbsp;Rejected</h4>

    
    
    
    
    
    
       
  </ul>
</div>
  
            </div> 
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>

        
        
        
        
        
        
        
        
        
        
        
        <?php include 'home/footer.php';?></div></center></body>  
</html> 