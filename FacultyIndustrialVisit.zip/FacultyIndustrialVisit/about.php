<!DOCTYPE html>
<html>
    <head><link href="css/styles.css">
        <style>.card {
    transition: 0.3s;
    border-radius: 5px;
}
</style></head>
    <body><br><br><br><br><br>
        
        <div align="center">
            <div class="card" style="background-color: #fff;width: 85%; height: 1000px;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);">
                <?php include 'home/header.php'; ?><br><?php include ('home/menu.php');?><br><br><br><br>
<img src="image/aboutus.jpg"width=125px" height="125px" ><br>
<div style="color:black;font-family: calibri;font-style: bold;font-size: 24px;word-break:keep-all;margin-right: 100px ;margin-left: 100px;" align="left"><br>
    <p><img src="image/bulle.jpg" width="25px" height="25px">&nbsp;&nbsp;An active Industry Institute Interaction Cell (III Cell) has been functioning in the College.<br>
        <img src="image/bulle.jpg" width="25px" height="25px">&nbsp;&nbsp;The function of the Cell is to promote closer interaction between the academic field and the &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;professional field.<br>
    <img src="image/bulle.jpg" width="25px" height="25px">&nbsp;&nbsp;Industry Institute Interaction Cell is established to provide closer links with industries.<br>
    <img src="image/bulle.jpg" width="25px" height="25px">&nbsp;&nbsp;The purpose of the cell is to find out the gap between need of the industry and end product &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;of the institute. <br>
    <img src="image/bulle.jpg" width="25px" height="25px">&nbsp;&nbsp;The cell is the bridge between the industry, the real world and the institute. <br>
    <img src="image/bulle.jpg" width="25px" height="25px">&nbsp;&nbsp;Industrial exposure of Faculty is very much helpful to guide students about latest industrial &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;practices. <br>
    <img src="image/bulle.jpg" width="25px" height="25px">&nbsp;&nbsp;Industries are able to know recent developments and inventions in their fields and &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;implement projects for technologically driven economy.<br>
    </p></div>

<br><br>
<br><br>
        
        
        
        
        
        
        
        
        
        
        
        <?php include 'home/footer.php';?></div></div></body>  
</html> 