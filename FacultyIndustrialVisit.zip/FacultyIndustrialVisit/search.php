<html>
    </head>
            <link rel="stylesheet" type="text/css" href="css/component.css" />
            <link rel="stylesheet" type="text/css" href="css/scss.css">
                <style>
                    #icon{
                        background-image:url(image/s.png);
                    }
           
</style></head>
    <body><center><br><br><br><br><br><div style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1000px"><?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>

                    <center> 
                        <div class="card"><br><br>
                            <h1>Search Industry</h1><br>
                                <image src="image/search.jpg" width="75px" height="75px"/><br><br>
                                    <form method="post" action="search.php">
                                        <div class="drop">
                                            <select name="one" class="drop-select" required>
                                                <option value="">Select Based On</option>
                                                <option value="1">Industry Name</option>
                                                <option value="2">Industry E-Mail / web site</option>
                                                <option value="3">Location</option>
                                                <option value="4">Nature</option>

                                            </select>
                                        </div><br><br><br>
                                        <input id="icon" style="text-indent:17px;" type="text" placeholder="Search..."name ="industry" required/><br><br>
                                        <button class="button" name="search">Search</button>      
                                    </form><br><br>
                        </div><br>
                    <center><div class="card6">
<?php
    if(isset($_POST['search'])){
        if(empty($_POST['industry'])){
            echo'<center><h3 style="font-style:bold;">Enter Anything To Search...</h3></center>';
        }else{
            echo'<table>';
                echo'<thead>';
                    echo'<tr>';
                        echo'<th>IndustryName</th>';
                        echo'<th>Address</th>';
                        echo'<th>Location</th>';
                        echo'<th>E-Mail</th>';
                        echo'<th>Contact Person</th>';
                        echo'<th>Mobile No</th>';
                    echo'</tr>';
                echo'</thead>';
            echo'<tbody>';
            $word=$_POST['industry'];
            $word=strtolower($word);
            $count=str_word_count($word);
            require 'dbconnect.php';   
                if($_POST['one']=='1'){ 
                    $query="SELECT * FROM industry WHERE industryname LIKE '%" . $word . "%'";
                    $sql = $conn->query($query); 
                        if($sql->num_rows >0) {
                            while($row = $sql->fetch_assoc()) 
                            {
                                  echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';
                                                         
                            }                        
                        }elseif($count>1){
                            $pieces = explode(" ", $word);
                            $query1="SELECT * FROM industry WHERE industryname LIKE '%" .$pieces[0] . "%'";
                            $query2="SELECT * FROM industry WHERE industryname LIKE '%" .$pieces[1] . "%'";
                                $sql1 = $conn->query($query1); 
                                $sql2 = $conn->query($query2); 
                                    if($sql1->num_rows >0){
                                        while($row = $sql1->fetch_assoc()) 
                                        {
                                  echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';
                                                                              
                                        }
                                    }elseif($sql2->num_rows >0){
                                        while($row = $sql2->fetch_assoc()) 
                                        {
                                           
                                  echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';
                                        }                                          
                                    }else{
                                        echo '<tr ><td colspan="7" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                    }
                        }else{
                            echo '<tr ><td colspan="7" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                        }
                }
                if($_POST['one']=='2'){ 
                    $query="SELECT * FROM industry WHERE email LIKE '%" . $word . "%'";
                    $sql = $conn->query($query); 
                        if($sql->num_rows >0){
                            while($row = $sql->fetch_assoc()) 
                            {                                                              echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';

                            }                        
                        }elseif($count>1){
                            $pieces = explode(" ", $word);
                            $query1="SELECT * FROM industry WHERE email LIKE '%" .$pieces[0] . "%'";
                            $query2="SELECT * FROM industry WHERE email LIKE '%" .$pieces[1] . "%'";
                            $sql1 = $conn->query($query1); 
                            $sql2 = $conn->query($query2); 
                                if($sql1->num_rows >0){
                                    while($row = $sql1->fetch_assoc()) 
                                   {
                                  echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';
                                    
                                    }
                                }elseif($sql2->num_rows >0){
                                    while($row = $sql2->fetch_assoc()) 
                                    {
                                  echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';
       
                                    }                                          
                                }else{
                                    echo '<tr ><td colspan="7" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                                }
                        }else{
        echo '<tr ><td colspan="7" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
    }
                }
                
                
                if($_POST['one']=='3'){ 
            $query="SELECT * FROM industry WHERE location LIKE '%" . $word . "%'";
                $sql = $conn->query($query); 
                if($sql->num_rows >0){
                    while($row = $sql->fetch_assoc()) 
                    {
                                  echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';
                          }                        
                }
            elseif($count>1){
                $pieces = explode(" ", $word);
                $query1="SELECT * FROM industry WHERE location LIKE '%" .$pieces[0] . "%'";
                        $query2="SELECT * FROM industry WHERE location LIKE '%" .$pieces[1] . "%'";
                        $sql1 = $conn->query($query1); 
                        $sql2 = $conn->query($query2); 
                        if($sql1->num_rows >0){
                            while($row = $sql1->fetch_assoc()) 
                           {                                                              echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';
}
                        }elseif($sql2->num_rows >0){
                            while($row = $sql2->fetch_assoc()) 
                            {                                                             echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';
 }                                          
                        }
                        else{
                        echo '<tr><td colspan="7" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                        }
            }
    else{
        echo '<tr ><td colspan="7" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
    }
                }
    
                   
                if($_POST['one']=='4'){ 
            $query="SELECT * FROM industry WHERE industrynature LIKE '%" . $word . "%'";
                $sql = $conn->query($query); 
                if($sql->num_rows >0){
                    while($row = $sql->fetch_assoc()) 
                    {
                                                                                    echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';
   }                        
                }
            elseif($count>1){
                $pieces = explode(" ", $word);
                $query1="SELECT * FROM industry WHERE industrynature LIKE '%" .$pieces[0] . "%'";
                        $query2="SELECT * FROM industry WHERE industrynature LIKE '%" .$pieces[1] . "%'";
                        $sql1 = $conn->query($query1); 
                        $sql2 = $conn->query($query2); 
                        if($sql1->num_rows >0){
                            while($row = $sql1->fetch_assoc()) 
                           {                                                          echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';
    }
                        }elseif($sql2->num_rows >0){
                            while($row = $sql2->fetch_assoc()) 
                            {                                                             echo '<tr><td style="color:#f67854" class="user-name">'.$row['industryname'] .'</td><td class="user-name">'.$row['industryaddress'] .'</td><td class="user-name">'.$row['location'] .'</td><td class="user-name">'.$row['email'] .'</td><td class="user-name">'.$row['cpname'] .'</td><td class="user-name">'.$row['cpmobileno'] .'</td></tr>';
 }                                          
                        }
                        else{
                        echo '<tr><td colspan="7" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
                        }
            }
    else{
        echo '<tr ><td colspan="7" style="color:#f67854" class="user-name"><br><p style="text-align:center;">No Record Found</p></td></tr>';
    }
                }
    
                
              if($_POST['one']==""){
                    echo'<center><h3 style="font-style:bold;color:red;">Please Select , Search Industry Based On</h3></center>';
              }
                            
                            
                mysqli_close($conn);

                
               
    }}
               echo' </tbody>';
               echo' </table>';?></div></center>
        </body>                <?php include 'home/footer.php';?>

    </div>
</html>

