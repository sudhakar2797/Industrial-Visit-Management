<?php if (session_status() == PHP_SESSION_NONE) {session_start();}
require 'dbconnect.php';
$id=$_SESSION['smid'];
$placement=$campus="no";
$cper="";
if(isset($_POST['submit'])){
    
    if (isset($_POST['placement'])){
       $placement="yes"; 
    }
    if (isset($_POST['campus'])){
    $campus="yes";
            $cper=$_POST['cper'];
    }
    $pov=$_POST['pov'];
    $eiti=$_POST['eiti'];
    $adv=$_POST['adv'];
    $old= strtotime($adv);
    $adv= date('Y-m-d ', $old);
    $doi=$_POST['doi'];
    $pname=$_POST['pname'];
    $pdg=$_POST['pdg'];
    $nvmis=$_POST['nvmis'];
    $nvmiay=$_POST['nvmiay'];
    $dop=$_POST['dop'];
    $old= strtotime($dop);
    $dop= date('Y-m-d ', $old);
    $any=$_POST['any'];
    $dos=date("M Y");
    
     $sql="UPDATE report SET placement_opportunity = '$placement' , campus_interview = '$campus' , interview_contactperson = '$cper' , purposeofvisit = '$pov' , industry_experience = '$eiti' , actualdateofvisit = '$adv' , industry_distance = '$doi' , person_met_name = '$pname' , designation = '$pdg' , noofvisitinsemester = '$nvmis' , noofvisitinyear = '$nvmiay' , dateofpresent = '$dop' , anyother = '$any' , dateofsubmit = '$dos' WHERE id= '$id'";
      $sql1="UPDATE faculty SET  reportstatus = 'reportsubmitted' WHERE id= '$id'";
                 
     if((mysqli_query($conn,$sql))&&(mysqli_query($conn,$sql1))){
         $staffid=$_SESSION['id'];
          $sql = "SELECT * FROM  staffdetails  WHERE  StaffId='$staffid'";
                            $result = $conn->query($sql);
                                if($result->num_rows >0){
                                    while($row = $result->fetch_assoc()){
                                        $staffname=$row['StaffName'];
                                        $desig=$row['Designation'];
                                        $depid=$row['DepartmentId'];
                                    $sql1 = "SELECT * FROM  deptmaster  WHERE  id='$depid'";
                            $result1 = $conn->query($sql1);
                            if($result1->num_rows >0){
                                    while($row1 = $result1->fetch_assoc()){
                            $depart=$row1['name'];}}
                                        $from=$row['EmailId'];
                                }}
                                             $subject = " Industrial Visit Report Submission ";

         $headers  = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
               
                            $message = "
                            <html>
        <body style='width: 1000px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 1000px; '><center><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'>IV Report Submission</p></center>
                </div>        <pre style=' font-size:20px;font-family:calibre;'>   
    Faculty Name                              :     ".$staffname." 
        
    Department                                  :     ".$depart."

    Designation                                 :     ".$desig."

    Email ID                                    :     ".$from."               
                        </pre>
      
        </body></html>";
                        require 'config.php';
                       foreach($contact as $contact){
                            $result=mail($contact,$subject, $message, $headers); 
                    } if (($result)) {
                                   
         
         ?>
             <!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" media="all" href="css/app.css">
    </head>
            <body><center><br><br><br><br><br><div class="card" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1000px"><?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>
                  <div class="div6" style="background-color: white"><br>
                    <img src="image/submit.jpg"width="100px" height="100px">
                    <div class="div5">      
                        <h1 style="color:white; font-family:calibri; text-align: center;font-size: 20px">submitted</h1>
                    </div><br><br>
                    <a href="home.php"><button class="but" ><span><< BACK TO &nbsp;  </span></button></a><br><br>
                </div>
            </center>
        </body>
</html>

                    <?php }else {
                                $_SESSION['reerror']="Submitted,Unable To Send Mail NetWork Error";
                                        header("location: report.php");
                            }} else {
                                $_SESSION['reerror']="Check Your Data,Please Try Again";
                                        header("location: report.php");
                            }
}



mysqli_close($conn);
?> 