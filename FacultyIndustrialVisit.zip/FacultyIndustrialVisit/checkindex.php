  <?php
    session_start();
        if(isset($_POST['mainsubmit'])) {
                include('dbconnect.php');
                           
                $count;
                            $fname=$_SESSION['name'];
                            $desig=$_SESSION['desig'];
                            $dep=$_SESSION['dep'];
                            $sid=$_SESSION['log'];
                            $email=$_SESSION['email'];
                            $dot=$_POST['dot'];
                            $old = strtotime($dot);
                            $dot= date('Y-m-d ', $old); 
                            $doa=date('Y-m-d');
                            $mobile=$_SESSION['mobile'];
                            $dov=$_POST['dov'];
                            $remark=$_POST['remark'];
                            $hodr="pending";
                            $da="pending";
                            $rere="no";
                            $report="pending";
        $security = mt_rand(100000, 999999);
        $stmt = $conn->prepare("INSERT INTO faculty VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("issssisissss",$count,$sid,$dep,$doa,$dot,$dov,$remark,$security,$hodr,$da,$rere,$report);
                            $noi=$_POST['noi'];
                            $nri=$_POST['nri'];
                            $aoi=$_POST['aoi'];
                            $city=$_POST['city'];
                            $iemail=$_POST['iemail'];
                            $conper=$_POST['conper'];
                            $conperno=$_POST['conperno'];
        $stmt1 = $conn->prepare("INSERT INTO industry VALUES (?,?,?,?,?,?,?,?)");
        $stmt1->bind_param("isssssss",$count,$noi, $nri,$aoi,$city,$iemail,$conper,$conperno);
                            if(($stmt->execute())&&($stmt1->execute())){
                                    $subject = "Request for Industrial Visit";
                                     $sql = "SELECT * FROM  faculty  ";
                            $result = $conn->query($sql);
                            if ($result->num_rows >0) {
                            $count=$result->num_rows;}
                            
                                    $id=base64_encode($count);
                                    require 'config.php';
                                   $recommendurl=$recommendurl."?id=$id";

$message="        
            
<html>
<head>
                <title>Faculty Industrial Visit</title>
            </head>
            <body style='width: 1000px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>
            <div><center><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'>Faculty Industrial Visit Approval Form Details</p></center>
                </div> <pre style='style:bold; font-family:calibri; text-align: left;font-size: 20px;word-wrap:break-word;display:inline;'>
            Facultyname                :   ".$fname."

            Designation                  :   ".$desig."

            Department                 :   ".$dep."

            Email-ID                        :   ".$email."

            Mobile Number           :   ".$mobile."

            Industry Name             :   ".$noi."

            Industry Nature           :   ".$nri."

            Industry Address          :   ".$aoi."

            Date Of Apply               :   ".$doa."

            Date Of Visit                  :   ".$dot."

            Duration Of Visit           :   ".$dov."

            Contact Person              :   ".$conper."

            Mobile No                       :   ".$conperno."

            Remarks		   :   ".$remark."

            Authentication Code    :   <h5 style='color:green;font-size:25px;text-align:center;display:inline;'>".$security."</h5>
            
            Please Click Here To Recommend / Reject     :<br>   ".$recommendurl."</pre>
                   <pre>                                                    
                </body></html>";
                    $depid=$_SESSION['depid'];
                    $sql = "SELECT * FROM  deptdetails where DeptId='$depid'";
                    $result = $conn->query($sql);
                    if ($result->num_rows >0) {
                        while($row = $result->fetch_assoc()) {
                    $to=$row['EmailId'];}}
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                    
                    $result=mail($to,$subject, $message, $headers);   
                        if ($result) {
                            
                                header("location: submit.php");
                        }else{
                                    $_SESSION['msg'] = "Requested Successfully ,Unable To Send Mail NetWork Error"; 
                                    header("location: index1.php");     
                                }
                            
                            }
                             else{
                                    $_SESSION['msg'] = "Invalid Data Please Check Your Data And Try Again"; 
                                    header("location: index1.php");     
                                }
                    }
          
mysqli_close($conn);?>   
