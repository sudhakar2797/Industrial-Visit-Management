
<?php
$month=$depart="";
 if (isset($_GET['showme'])){
$month=$_GET['month'];
$month= strtotime($month);
$month=date('Y',$month);
 }
 require('fpdf.php');

class PDF extends FPDF
{
// Page header
function Header()
{
$month=$_GET['month'];

// Logo
	$this->Image('image/kcet.png',100,6,100,15);
	// Arial bold 15
$this->Ln(20);
$this->SetY(25);
        $this->SetX(125);
	// Arial italic 8
	$this->SetFont('Arial','B',10);
		$this->Cell(0,0,"Year : ".$month,0,0,'l');
                $this->SetY(25);
        $this->SetX(250);
	
	
}

// Page footer
function Footer()
{
	// Position at 1.5 cm from bottom
	$this->SetY(-10);
                $this->SetX(0);

	// Arial italic 8
	$this->SetFont('Arial','I',8);
	// Page number
	$this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');

        
    date_default_timezone_set('Asia/Kolkata');
$date=date('d-m-Y h:i:sa');
	// Position at 1.5 cm from bottom
	$this->SetY(-11);
        $this->SetX(140);
	// Arial italic 8
	$this->SetFont('Arial','B',11);
		$this->Cell(0,0,$date,0,0,'C');

}
}



// Instanciation of inherited class
$pdf = new PDF();
$pdf->AddPage('L','A4');
	     
//Fields Name position
$Y_Fields_Name_position = 30;
//Table position, under Fields Name
$Y_Table_Position = 36;

//First create each Field Name
//Gray color filling each Field Name box
$pdf->SetFillColor(232,232,232);
//Bold Font for Field Name
$pdf->SetFont('Arial','B',8);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(5);
$pdf->Cell(15,6,'S.N0',1,0,'L',1);
$pdf->SetX(20);
$pdf->Cell(20,6,'StaffID',1,0,'L',1);
$pdf->SetX(40);
$pdf->Cell(60,6,'Name',1,0,'L',1);
$pdf->SetX(100);
$pdf->Cell(25,6,'VisitDate',1,0,'L',1);
$pdf->SetX(125);
$pdf->Cell(60,6,'IndustryName',1,0,'L',1);
$pdf->SetX(185);
$pdf->Cell(60,6,'ContactPerson',1,0,'L',1);
$pdf->SetX(245);
$pdf->Cell(20,6,'Department',1,0,'L',1);
$pdf->SetX(265);
$pdf->Cell(30,6,'Status',1,0,'L',1);

$pdf->Ln();
$sno=1;

//Connect to your database
include("dbconnect.php");

//Select the Products you want to show in your PDF file
$query="select * from faculty where YEAR(dateofvisit) = '$month' order by department ";
$sql = $conn->query($query);
$number_of_records = $sql->num_rows;

while ($row=$sql->fetch_assoc()){
    $id=$row['id'];
    $staffid=$row['StaffID'];
    $de=$row['department'];
    $status=$row['reportstatus'];

    
    
    $sql1="select * from report where id = '$id' and dateofsubmit LIKE '%$month%'";
$result2 = $conn->query($sql1);
$row1= $result2->fetch_assoc();
    $staffname = $row1['staffname'];
    $adv = $row1['actualdateofvisit'];
    $conper = $row1['person_met_name'];
     
    
    

     
    
    $sql0="select * from industry where id = '$id' ";
$result = $conn->query($sql0);
$row0= $result->fetch_assoc();
    $industryname = $row0['industryname'];
    $conper = $row0['cpname'];
    
    
    if(($status=="pending")||($result2->num_rows==0)){
    $sql8="select StaffName from staffdetails where StaffId = '$staffid' ";
$result = $conn->query($sql8);
$row8= $result->fetch_assoc();
    $staffname = $row8['StaffName'];
        $adv = $row['dateofvisit'];
    }
    
   
    
//Now show the 3 columns
$pdf->SetFont('Arial','',10);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(5);
$pdf->MultiCell(15,6,$sno,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(20);
$pdf->MultiCell(20,6,$staffid,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(40);
$pdf->MultiCell(60,6,$staffname,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(100);
$pdf->MultiCell(25,6,$adv,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(125);
$pdf->MultiCell(60,6,$industryname,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(185);
$pdf->MultiCell(60,6,$conper,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(245);
$pdf->MultiCell(20,6,$de,1);
$pdf->SetY($Y_Table_Position);
$pdf->SetX(265);
$pdf->MultiCell(30,6,$status,1);
$pdf->SetY($Y_Table_Position);




$Y_Table_Position+=12;
$sno++;

if($Y_Table_Position>=180){$pdf->AddPage('L','A4');
	     
//Fields Name position
$Y_Fields_Name_position = 30;
//Table position, under Fields Name
$Y_Table_Position = 36;}





  }
//For each row, add the field to the corresponding column
$pdf->Output();
?>