<!DOCTYPE html>
<html>
    <head><link href="css/styles.css">
        <style>.card {
    transition: 0.3s;
    border-radius: 5px;
}
 .but {
  border-radius: 4px;
  background-color: #357ae8;
  border-radius:100px;;
  color: #FFFFFF;
  text-align: center;
  font-size: 16px;
  padding: 10px;
  width: 100px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}
</style></head>
    <body><center><br><br><br><br><br><div class="card" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1000px"><?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>
            <br>        <img src="image/help.jpg"width=125px" height="125px" >
<br>
<br><br>
<h2 style="font-family: calibri;font-size:28px;color: black;font-style: bold;"> Please Contact Your Department i3 Cell Coordinator Or Click Here To Contact Us</h2>
<br><a href="login.php"><button class="but">Click Me</button></a><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>
<br><br>

        
        
        
        
        
        
        
        
        
        
        
        <?php include 'home/footer.php';?></div></center></body>  
</html> 