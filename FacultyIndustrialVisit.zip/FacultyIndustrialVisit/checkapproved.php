<?php
    session_start();
        $id=$_SESSION['eid'];
        include('dbconnect.php');
            if (!empty($_POST['valid'])){
                $security=$_POST['valid'];
                $sql = "SELECT id FROM  faculty WHERE id='$id' AND security='$security'";
                $result = $conn->query($sql);
                    if ($result->num_rows==0){
                        $_SESSION['msg'] ="Please Enter Valid Authentication Code";
                        header("location: approval.php"); 
                                             }
                    elseif(isset($_POST['app'])) {
                           $DEANremark="DEAN::".$_POST['req'];
                           $sql = "UPDATE faculty SET deanapproval='approved' WHERE id='$id'";
                           $sql1="update faculty set remark=concat(remark, '$DEANremark') WHERE id='$id'";
                            if((mysqli_query($conn,$sql))&&(mysqli_query($conn,$sql1))){

                                    $subject = "Industrial Visit Request Is Approved  ";
                                    $headers = "MIME-Version: 1.0" . "\r\n";
                                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                                    $message = "
                                    <html>
        <body style='width: 1000px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 1000px;'><center><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'>IV Request Status</p></center>
                </div>

                        <pre style=' font-size:20px;font-family:calibre;'>   
    Faculty Name                              :     ".$_SESSION['name']." 
        
    Industry Name                             :     ".$_SESSION['noi']."

    Dean Approval Status                   :    Approved

                    </pre>
        </body></html>";
                                    $depid=$_SESSION['depid'];
                                    $sql = "SELECT EmailId FROM  deptdetails where DeptId='$depid'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows >0) {
                                        while($row = $result->fetch_assoc()) {
                                    $hodmail=$row['EmailId'];}}
                                    $result=mail($hodmail,$subject, $message, $headers); 
                                    
                                    $message = "
                                                                                  
<html>
        <body style='width: 1000px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 1000px;'><center><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'>IV Request Status</p></center>
                </div>

                        <pre style=' font-size:20px;font-family:calibre;'>   
    Faculty Name                              :     ".$_SESSION['name']." 
        
    Industry Name                             :     ".$_SESSION['noi']."

    Dean Approval Status                  :    Approved 

    HOD  Recommendation Status   :    Recommended 

        
                        </pre>
      
        </body></html>";
                                    
                                    $facultymail=$_SESSION['email'];
                                    $result1=mail($facultymail,$subject, $message, $headers); 
                                        require 'config.php';
                                    $result2=mail($cto,$subject, $message, $headers); 
                                    if($result2){
                                        if(($result)&&($result1)) {
                                            header("location: thankyou.php");
                                        }
                                        
                                        }else{ 
                                            $_SESSION['msg'] = "Please Try Again";
                                            header("location: approval.php"); 
                                           }  
                                }else{ 
                                $_SESSION['msg'] = "Please Try Again";
                                header("location: approval.php"); 
                            }
                       
                    }
 //-----------------------------------------------------------------------------------------------//
        elseif(isset($_POST['notapp'])) {
            if (empty($_POST['req'])) {
                $_SESSION['msg'] ="Remark Is Required";
                header("location: approval.php"); }
                else{
                    $remark="DEAN::". $_POST['req'];
                    $sql = "UPDATE faculty SET deanapproval='not approved' WHERE id='$id'";
                    $sql1="update faculty set remark=concat(remark, '$remark') WHERE id='$id'";
                        if((mysqli_query($conn,$sql))&&(mysqli_query($conn,$sql1))){
                                                $subject = " Industrial Visit Request Rejected By Dean";
                                                $message = "
                                                
<html>
        <body style='width: 1000px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 1000px; '><center><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'>IV Request Status</p></center>
                </div>

                        <pre style=' font-size:20px;font-family:calibre;'>   
    Faculty Name                              :     ".$_SESSION['name']." 
        
    Industry Name                             :     ".$_SESSION['noi']."

    Dean Recommendation Status    :     REJECTED

    Remarks                                       :     ".$_POST['req']. "
        
                        </pre>
        </body></html>";
                                                    
                            $headers = "MIME-Version: 1.0" . "\r\n";
                            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                            $headers .= 'From: '.$from."\r\n";
                                    $facultymail=$_SESSION['email'];
                                    $depid=$_SESSION['depid'];
                                    $sql = "SELECT EmailId FROM  deptdetails where DeptId='$depid'";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows >0) {
                                        while($row = $result->fetch_assoc()) {
                                            $hodmail=$row['EmailId'];}}
                                    
                            $result=mail($facultymail,$subject, $message, $headers); 
                            $result1=mail($hodmail,$subject, $message, $headers); 
                                                        $result2=mail($cto,$subject, $message, $headers); 
                            if ($result2){
                                if (($result)&&($result1)) {
                                            header("location: reject.php");
                                        }
                                        }else{ 
                                            $_SESSION['msg'] = "Please Try Again";
                                            header("location: approval.php"); 
                                           }  
                               }else{ 
                                    $_SESSION['msg'] = "Please Try Again";
                                     header("location: approval.php"); 
                                    }
                }  
        }       
            }else{
                $_SESSION['msg'] ="Please Enter Authentication Code";
                header("location: approval.php"); 
                }
 
               mysqli_close($conn); ?>



       