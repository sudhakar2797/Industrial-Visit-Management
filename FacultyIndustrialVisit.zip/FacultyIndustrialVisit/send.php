<?php if (session_status() == PHP_SESSION_NONE) {session_start();}?>

<?php 

if (isset($_POST['send'])){
     require 'dbconnect.php'; 
                            $date=date('Y-m-d');
                            $query="SELECT * FROM faculty WHERE reportstatus ='pending' ";
                            $sql = $conn->query($query); 
                                if($sql->num_rows >0) {
                                    while($row = $sql->fetch_assoc()) 
                                    { $staffid=$row['StaffID'];
                                    $date=$row['dateofvisit'];
                                        $date1=$row['dateofvisit'];
                                        $date2=date('Y-m-d');
                                        $ts1 = strtotime($date1);
                                            $ts2 = strtotime($date2);

                                                    $seconds_diff = $ts2 - $ts1;
                                            $seconds_diff=$seconds_diff/(60*60*24);
                                             if($seconds_diff>=7){
                                                 $query1="SELECT * FROM staffdetails WHERE StaffId='$staffid' ";
                                        $sql1 = $conn->query($query1); 
                                            if($sql1->num_rows >0) {
                                              while($row1 = $sql1->fetch_assoc()) 
                                                {
 $subject = "Industrial Visit Report Submission Alert  ";
                                    $message = "
                                    <html>
        <body style='width: 1000px; border-radius: 1.5px; text-align: justify; border: 4px solid #357ae8 ;word-wrap: word-break; '>

            <div style= 'width: 1000px;'><center><p style='color:crimson; font-size:25px;font-family:calibre;text-align: center;'>IV Report Mail Alert</p></center>
                </div>
                    
                        <pre style=' font-size:20px;font-family:calibre;'>   
    Faculty Name                              :     ".$row1['StaffName']." 
        
    Date Of Visit                              :     ".$date."

                    </pre>
                     <h2 style='color:bule;'>  ....!!! Please Submit Your Industrial Visit Report !!!....</h2>

        </body></html>";
                                  $remail=$row1['EmailId'];
                                    $headers = "MIME-Version: 1.0" . "\r\n";
                                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                                    
                                    $message = wordwrap($message, 70);
                                    $result=mail($remail,$subject, $message, $headers);   
                                        

}}}}}

if ($result) {
                                            $_SESSION['merror'] = "Message has been Successfully Send";
                                            header("location: mailalert.php");
                                        }else{
                                            echo $_SESSION['merror'] = "Please Try Again Network Error";
                                            header("location: mailalert.php");  
                                        }



                                                }



?>