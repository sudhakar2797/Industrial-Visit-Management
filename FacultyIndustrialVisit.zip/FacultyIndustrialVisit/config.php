<?php 
//menu.php
//admin menu  authendication
$ad="T0908312";

//login.php,checkappred.php
//coordinator mail-id
$cto="sudhakar.it.12345@gmail.com";

//checkindex.php
//recommendation Page URL
$recommendurl="http://localhost/FacultyIndustrialVisit/recommend.php";

//checkapproved.php
//approvalpageURL
$approvedurl="http://localhost/FacultyIndustrialVisit/approval.php";

//checkrecommend.php
//mail from hod to Dean and coordinator for approval
$contacts=array(
    "sudhakar.it.12345@gmail.com",
    "sudhakar.it.12345@gmail.com"
);

//report3.php
//Report Submitted Intimatiom mail
$contact=array(
    "sudhakar.it.12345@gmail.com",
    "sudhakar.it.12345@gmail.com"
);
?>