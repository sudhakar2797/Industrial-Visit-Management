<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" media="all" href="css/app.css">
    </head>
            <body><center><br><br><br><br><br><div class="card" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1000px"><?php include 'home/header.php'; ?><br><?php include 'home/welcome.php';?><br><br><br>
                <div class="div6" style="background-color: white"><br>
                    <img style="display: inline;"src="image/approved.jpg"width="100px" height="100px">
                    <img style="display: inline;"src="image/thankyou.jpg"width="100px" height="100px">
                    <div class="div5">      
                        <h1 style="color:white; font-family:calibri; text-align: center;font-size: 18px"><b> APPROVED</b></h1>
                    </div><br><br>
                    <a href="welcome.php"><button class="butt"><span><< BACK TO &nbsp;</span></button></a><br><br>
                </div>
            </center>
        </body>
</html>


