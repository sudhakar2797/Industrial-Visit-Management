<!DOCTYPE html>
<html>
    <head>         
        <?php if (session_status() == PHP_SESSION_NONE) {session_start();}?>
        <link rel="stylesheet" type="text/css" media="all" href="css/app.css">
        <?php if(isset($_GET['id'])){
        $_SESSION['id']=$_GET['id'];}?>
    </head>
    <body><center><br><br><br><br><br><div class="card" style="background-color: #fff;width: 85%; height: 2200px;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);"><?php include 'home/header.php'; ?><br><p style="width:500px;"><?php include'home/welcome.php';?><br><br><br>
<div class="p3"><br>
                    <p style="color:white; font-family:calibri; text-align: center;font-size: 40px"> Industrial Visit </p>

                          <?php if(!empty($_SESSION['msg'])){?>
            <link href="css/alert.css" rel="stylesheet">
                                        <div class="alert" style="width: 50%">
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $_SESSION['msg'];?>
                                     </div><?php }?>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script>                <div class="div2"><br><br><br><h1 style="color:#357ae8; font-family:calibri; text-align: center;font-size: 30px"> Approval </h1>
    <form method="post" action="checkapproved.php" name="myForm">
                        <p class="ss">
                            <input type="text" class="login-field" name="valid" placeholder="Authentication Code - Check Your Mail" id="login-name" autofocus="" required></p><br>
                                    <?php
                                            $_SESSION['eid']= base64_decode($_SESSION['id']);
                                            $id=$_SESSION['eid'];
                                        include('dbconnect.php');
                                        $sql = "SELECT * FROM  faculty WHERE  id='$id'";
                                        $result = $conn->query($sql);
                                            if($result->num_rows >0){
                                                while($row = $result->fetch_assoc()){
                                                    $_SESSION['dep']=$row['department'];
                                                    $_SESSION['doa']=$row['dateofapply'];
                                                    $_SESSION['dot']=$row['dateofvisit'];
                                                    $_SESSION['dov']=$row['noofdays'];
                                                    $_SESSION['remark']=$row['ivremark'];
                                                    $_SESSION['hodremark']=substr($row['remark'],5);
                                                    
                                                    $sid=$row['StaffID'];
          
                                                    }
                                                                     }               
                                        $sql = "SELECT * FROM  staffdetails  WHERE  StaffId='$sid'";
                                        $result = $conn->query($sql);
                                            if($result->num_rows >0){
                                                while($row = $result->fetch_assoc()){
                                                    $_SESSION['name']=$row['StaffName'];
                                                    $_SESSION['desig']=$row['Designation'];
                                                    $_SESSION['depid']=$row['DepartmentId'];
                                                    $_SESSION['mobile']=$row['ContactNo'];
                                                    $_SESSION['email']=$row['EmailId'];
                                            }} 
                                                 
                                            $sql = "SELECT * FROM  industry  WHERE  id=(SELECT id FROM faculty WHERE id='$id')";
                                            $result = $conn->query($sql);
                                            if ($result->num_rows >0){
                                                while($row = $result->fetch_assoc()){
                                                    $_SESSION['noi']=$row['industryname'];           
                                                    $_SESSION['conper']=$row['cpname'];
                                                    $_SESSION['conperno']=$row['cpmobileno'];
                                                    $_SESSION['aoi']=$row['industryaddress'];
                                                    $_SESSION['nri']=$row['industrynature'];
                                                                                    } 
                                                                    }
                                    ?>
                                <table class="table-fill"style="table-layout:fixed;">
                                    <col width="50">
                                    <col width="180">
                                        <thead>
                                            <tr colspan="2">
                                                <th colspan="2" class="text-left">Faculty Industrial Visit Details</th>
                                            </tr>
                                        </thead>
                                            <tbody class="table-hover">
                                                <tr>
                                                    <td class="text-left">Faculty Name</td>
                                                    <td class="text-left"><?php echo  $_SESSION['name']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Designation</td>
                                                    <td class="text-left"><?php echo  $_SESSION['desig']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Department</td>
                                                    <td class="text-left"><?php echo  $_SESSION['dep']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Email-ID</td>
                                                    <td class="text-left"><?php echo $_SESSION['email']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Mobile Number</td>
                                                    <td class="text-left"><?php echo $_SESSION['mobile']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Industry Name</td>
                                                    <td class="text-left"><?php echo  $_SESSION['noi']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Industry Nature</td>
                                                    <td class="text-left"><?php echo  $_SESSION['nri']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Industry Address</td>
                                                    <td class="text-left"><?php echo  $_SESSION['aoi']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Date Of Apply</td>
                                                    <td class="text-left"><?php echo  $_SESSION['doa']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Date Of Visit</td>
                                                    <td class="text-left"><?php echo  $_SESSION['dot']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Duration In Days</td>
                                                    <td class="text-left"><?php echo  $_SESSION['dov']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Contact Person</td>
                                                    <td class="text-left"><?php echo  $_SESSION['conper']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Contact Person No</td>
                                                    <td class="text-left"><?php echo  $_SESSION['conperno']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">Remark</td>
                                                    <td  class="text-left"><?php echo  $_SESSION['remark']; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">HOD Recommend</td>
                                                    <td class="text-left"><?php echo'Recommended'; ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="text-left">HOD Remark</td>
                                                    <td  class="text-left"><?php echo  $_SESSION['hodremark']; ?></td>
                                                </tr>
                                            </tbody>
                                </table><br><br><br><br><br>
                                    <p class="ss">
                                        <input type="text" class="login-field" name="req" placeholder="Remarks About  Approed / Not Approved *" id="login-name"></p><br>
                                    <input onclick="myFunction()"style=" font-family:calibri; font-size: 20px;display:inline;" type="submit" name="app" class="login-submit" value="Approved">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                       <input onclick="myFunction()" style=" font-family:calibri; font-size: 20px;display:inline;" type="submit" name="notapp" class="login-submit" value="Not Approved *">
                     </form><?php if(!empty($_SESSION['msg'])){  unset($_SESSION['msg']);}?>
                </div>
<script>
function myFunction() {
    
    var x = document.forms["myForm"]["valid"].value;
    if (x == "") {
        document.getElementById('id01').style.display='none';

    }else{
document.getElementById('id01').style.display='block';
    } 
}

</script>

<style>


/* Center the image and position the close button */
.imgcontain {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;

   
}

.contain {
     width: 40%;
    border-radius: 50%;
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* The Modal (background) */
.modal {
    display: none;
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 40%; /* Could be more or less, depending on screen size */
}
/* The Close Button */
.close {
    /* Position it in the top right corner outside of the modal */
    position: absolute;
    right: 25px;
    top: 0; 
    color: #000;
    font-size: 35px;
    font-weight: bold;
}

/* Close button on hover */
.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}

/* Add Zoom Animation */
.animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}





.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 150px;
  height: 150px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}



h1{
	font-family: 'Actor', sans-serif;
	color:#357ae8;
	font-size:20px;
	letter-spacing:1px;
	font-weight:200;
	text-align:center;
}
.load span{
	width:16px;
	height:16px;
	border-radius:50%;
	display:inline-block;
	position:absolute;
	left:50%;
	margin-left:-10px;
	-webkit-animation:3s infinite linear;
	-moz-animation:3s infinite linear;
	-o-animation:3s infinite linear;
	
}


.load span:nth-child(2){
	background:#E84C3D;
	-webkit-animation:kiri 1.2s infinite linear;
	-moz-animation:kiri 1.2s infinite linear;
	-o-animation:kiri 1.2s infinite linear;
	
}
.load span:nth-child(3){
	background:#F1C40F;
	z-index:100;
}
.load span:nth-child(4){
	background:#2FCC71;
	-webkit-animation:kanan 1.2s infinite linear;
	-moz-animation:kanan 1.2s infinite linear;
	-o-animation:kanan 1.2s infinite linear;
}


@-webkit-keyframes kanan {
    0% {-webkit-transform:translateX(20px);
    }
   
	50%{-webkit-transform:translateX(-20px);
	}
	
	100%{-webkit-transform:translateX(20px);
	z-index:200;
	}
}
@-moz-keyframes kanan {
    0% {-moz-transform:translateX(20px);
    }
   
	50%{-moz-transform:translateX(-20px);
	}
	
	100%{-moz-transform:translateX(20px);
	z-index:200;
	}
}
@-o-keyframes kanan {
    0% {-o-transform:translateX(20px);
    }
   
	50%{-o-transform:translateX(-20px);
	}
	
	100%{-o-transform:translateX(20px);
	z-index:200;
	}
}
@-webkit-keyframes kiri {
     0% {-webkit-transform:translateX(-20px);
	z-index:200;
    }
	50%{-webkit-transform:translateX(20px);
	}
	100%{-webkit-transform:translateX(-20px);
	}
}

@-moz-keyframes kiri {
     0% {-moz-transform:translateX(-20px);
	z-index:200;
    }
	50%{-moz-transform:translateX(20px);
	}
	100%{-moz-transform:translateX(-20px);
	}
}
@-o-keyframes kiri {
     0% {-o-transform:translateX(-20px);
	z-index:200;
    }
	50%{-o-transform:translateX(20px);
	}
	100%{-o-transform:translateX(-20px);
	}
}



.blink_me {
  animation: blinker 1s linear infinite;
}

@keyframes blinker {  
  50% { opacity: 0; }
}
</style>
<body>

<div id="id01" class="modal" >
     
  <div class="modal-content animate" style="width:40%">
    <div class="imgcontain">
          <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>

      <div class="load" style="position:absolute;top:80px ;left:225px">
    <h1>LOADING</h1>
    <span></span>
    <span></span>
    <span></span>
</div> 
      
      <br><br><center><div class="loader"></div></center><br><br>
      
      <h1 ><b class="blink_me">Please Wait........</b></h1>

   </div>
</div></div>








</div><?php include 'home/footer.php';
mysqli_close($conn);?>
        </center>
    </body>
</html>

