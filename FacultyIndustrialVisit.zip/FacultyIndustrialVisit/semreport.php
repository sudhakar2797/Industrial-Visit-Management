

<html>
    <head>
        <link rel="stylesheet" href="css/report.css">

        <link rel="stylesheet" href="jq/jquery-ui.css">
        <script src="jq/jquery.js"></script>
        <script src="jq/jquery-ui.js"></script>
           
<style>


                    input[type=text] {
                        width: 190px;
                        height:44px;
                        box-sizing: border-box;
                        border: 2px solid #ccc;
                        border-radius: 4px;
                        font-size: 16px;
                        background-color: white;
                        background-repeat: no-repeat;
                        padding: 12px 20px 8px 45px;
                        -webkit-transition: width 0.4s ease-in-out;
                        transition: width 0.4s ease-in-out;
                    }
                    input[type=date]:focus {
                        width: 35%;
                    }
                    .card {
                        
                        transition: 0.3s;
                        width:55%;
                        border-radius: 50px;
                   background-color: white;}
                    h1{
                        
                        font-family: calibri;
                        font-style: bold;
                        font-size: 30px;
                    }
                </style>
    </head>
               <body><center><br><br><br><br><br><div  style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1000px"><?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>
                        <center>  
                            <div class="card" align="center"> <br>
                                <h1>Semester Wise  College Report</h1>
                                <form method="get" action="semreportpdf.php">
                                        <center><image src="image/report5.png" width="140px" height="120px"/></center><br><br>
                                        <input  style="background-image:url(image/from.png)" type="text" id="datepicker1" placeholder=" From Date..." name="from" required>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                              <input  style="background-image:url(image/to.png)" type="text" id="datepicker2" placeholder=" To Date..." name="to" required>
 <br><br>
                                        <button class="button" name="showme">Show Me</button>      
                                    </form><br>
                            </div>
                        </center>
                   </div>
        </body> <script>
                $( function(){
                $( "#datepicker" ).datepicker();
                $( "#format" ).on( "change", function() {
                $( "#datepicker" ).datepicker( "option", "dateFormat", $( this ).val() );
                });
                });
                $( function() {
                $( "#datepicker1" ).datepicker();
                $( "#format" ).on( "change", function() {
                $( "#datepicker1" ).datepicker( "option", "dateFormat", $( this ).val() );
                });
                });
                $( function() {
                $( "#datepicker2" ).datepicker();
                $( "#format" ).on( "change", function() {
                $( "#datepicker1" ).datepicker( "option", "dateFormat", $( this ).val() );
                });
                });
            </script>
           
</html>

    