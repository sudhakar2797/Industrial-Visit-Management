<!DOCTYPE html>
<html>
    <head><link href="css/styles.css">
        <style>.card {
    transition: 0.3s;
    border-radius: 5px;
}
</style></head>
    <body><center><br><br><br><br><br><div class="card" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 1400px"><?php include 'home/header.php'; ?><br><?php include 'home/welcome.php';?><br><br><br>
<br><br>
        <img src="image/home.png"width=200px" height="200px" >
        <style> p{
            text-align: justify;
}</style>
        <br><h2 style="font-family: calibri;color:#357ae8;font-size: 35px">Faculty Industrial Visit</h2>
<h3><div align="left" style="word-break: normal;color:black;margin-left: 100px;font-size: 18px;margin-right: 100px">
        <h1 style="font-size: 25px"><b><center>The Functions of Industry-Institute Interaction Cell</center></b></h1>
        <img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To give industrial exposure to Faculty members and students, thus enabling them to tune their knowledge to cope with the industrial culture</p><br>
        <img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To assist the Departments in organizing workshops, conferences and symposia with joint participation of the   industries</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Encouraging Engineers from industries to visit institution to deliver lectures</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Participation of experts from industries, in curriculum development</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To organize industrial visits for Faculty members and students</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To encourage Faculty members to use their expertise in solving the problems faced by the industries, thus creating opportunity for consultancy</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Industrial testing by Faculty and technician at site, or in laboratory</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To organize in-plant training for the students</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To identify the areas for executive development programmes in the areas of recent technological advances</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To assist the Departments in establishing rapport with industries for taking up mini projects and projects</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To coordinate/ identify industrial partners for proposing ‘Centre for Excellence’.</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To strengthen Alumni relations</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">To assist the Training and Placement Division</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Visit of industry executives and practicing engineers to the institute for seeing research work and laboratories</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Memorandum of Understanding between the institute and industries to bring the two sides emotionally and strategically closer</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">Visiting faculty from industries</p><br>
<img src="image/bulle.jpg"width="25px" height="25px"style="display: inline"><p style="display:inline;">R&D Laboratories sponsored by industries at the institute</p><br>
    
     <?php include 'home/footer.php';?>
       
    
    </div></h3><br><br>
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        </div></center></body>  
</html> 