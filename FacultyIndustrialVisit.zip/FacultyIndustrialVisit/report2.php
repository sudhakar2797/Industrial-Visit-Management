<?php if (session_status() == PHP_SESSION_NONE) {session_start();}?>
    <?php $entry=0;
require 'dbconnect.php';
$id=$_SESSION['smid'];
if(isset($_POST['second'])){
    $iv=$ipt=$pw=$gl="no";
    $nos1=$nos2=$nos3=$nos4=0;
    $nod1=$nod2=$nod3=$nod4=0;
    $dep1=$dep2=$dep3=$dep4="";
    $cp1=$cp2=$cp3=$cp4="";
    if(isset($_POST['possible']))
    {
        $iv="yes";
        $nos1=$_POST['nos1'];
        $nod1=$_POST['nod1'];
        $dep1=$_POST['dep1'];
        $cp1=$_POST['cp1'];
    }
    if(isset($_POST['possible1']))
    {
        $ipt="yes";
        $nos2=$_POST['nos2'];
        $nod2=$_POST['nod2'];
        $dep2=$_POST['dep2'];
        $cp2=$_POST['cp2'];
    }
    if(isset($_POST['possible2']))
    {
        $pw="yes";
        $nos3=$_POST['nos3'];
        $nod3=$_POST['nod3'];
        $dep3=$_POST['dep3'];
        $cp3=$_POST['cp3'];
    }
    if(isset($_POST['possible3']))
    {
        $gl="yes";
        $nos4=$_POST['nos4'];
        $nod4=$_POST['nod4'];
        $dep4=$_POST['dep4'];
        $cp4=$_POST['cp4'];
    }
    $stmt= $conn->prepare("INSERT INTO opportunity VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("isiisssiisssiisssiiss",$id,$iv,$nos1,$nod1,$dep1,$cp1,$ipt,$nos2,$nod2,$dep2,$cp2,$pw,$nos3,$nod3,$dep3,$cp3,$gl,$nos4,$nod4,$dep4,$cp4);
                            if($stmt->execute()){ 

$entry=1;   }   else {
                               $_SESSION['reerror']="Check Your Data,Please Try Again";
                                
                                 $sql = "SELECT * FROM  opportunity  WHERE  id='$id'";
                            $result = $conn->query($sql);
                                if($result->num_rows >0){
                                     if(!empty($_SESSION['reerror'])){  unset($_SESSION['reerror']);}
                                               $entry=1;                         
                                }else{
                                     header("location:report1.php");                         
                                }
                            }

}



mysqli_close($conn);

?>

<?php if($entry==1){?>


<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Report Form</title>
  
  
        <link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="jq/jquery-ui.css">
        <script src="jq/jquery.js"></script>
        <script src="jq/jquery-ui.js"></script>
        
      <link rel="stylesheet" href="css/style1.css">
 <script>
                $( function(){
                $( "#datepicker" ).datepicker();
                $( "#format" ).on( "change", function() {
                $( "#datepicker" ).datepicker( "option", "dateFormat", $( this ).val() );
                });
                });
                 $( function(){
                $( "#datepicker1" ).datepicker();
                $( "#format" ).on( "change", function() {
                $( "#datepicker1" ).datepicker( "option", "dateFormat", $( this ).val() );
                });
                });
                
            </script>

            <style>              
h7{
    font-family: calibri;
    font-size: 25px;
    color:#357AE8;
    float:left;
    margin-left: 20px;
}               
                
                
p{
   font-family: calibri;
    font-size: 20px;
    color:#fff;
    float:left;
    margin-left: 50px;  
}  </style>
</head>
<link rel="stylesheet" href="css/re.css">
    <body><center><br><br><br><br><br><div class="card" style="background-color: #fff;width: 85%;box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); height: 2500px"><?php include 'home/header.php'; ?><br><?php include 'home/menu.php';?><br><br><br>
<div class="bod" >
             <?php if(!empty($_SESSION['reerror'])){?>
                                
            <link href="css/alert.css" rel="stylesheet">
            <div class="alert success"  style="width:50%" >
                                        <span class="closebtn">&times;</span>  
                                       <?php  echo  $_SESSION['reerror'];?>
                                     </div>

                                     <script>
var close = document.getElementsByClassName("closebtn");
var i;

for (i = 0; i < close.length; i++) {
    close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script><?php }?>
                         
    <section class="login">
        <div class="titulo"><h1 style="color:#fff">Report Form</h1></div>	
        <form action="report3.php" method="post">
                        
                        
			<div >
                            <div >
                                <h7 >Placement Opportunity</h7>
			</div><br><br>
                            <div ><p><b> Will there Be Placement Opportunity For Freshers / Final Year ?</b></p><br><br>
<label class="switch">
  <input type="checkbox" name="placement" >
  <div class="slider"  style="color: white; font-family: calibri;style:bold;font-size: 25px;">&nbsp;&nbsp;&nbsp;&nbsp;yes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No</div>
</label>
                            </div><br>
                          
                            <div ><p><b>If So , Will Be interested in Coming For Campus interview ?</b></p><br><br>
                                
<label class="switch" >
  <input type="checkbox" name="campus" >
  <div class="slider"  style="color: white; font-family: calibri;style:bold;font-size: 25px;">&nbsp;&nbsp;&nbsp;&nbsp;yes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No</div>
</label><br><br>
</div>
                      <div ><p><b> If Yes , Person To Be Contacted</b></p><br><br><br><br>
                                <input type="text"   placeholder="Contact Person " name="cper" ><br><br>
				</div>      

                                     
                                                
                               
                                                    <div >
                                                        
                                <h7 >Other Details</h7><br><br>
                                          <p><b> Purpose of the Visit*</b></p><br><br><br><br>
                                <input type="text"   placeholder="Purpose of the Visit " name="pov" required><br><br>
                                
                                <p><b> Experience in This industry*</b></p><br><br><br><br>
                                <input type="text"   placeholder="Experience in This industry" name="eiti" required><br><br>
                                
                                <p><b> Actual Date of Visit*</b></p><br><br><br><br>
                                <input type="text"  id="datepicker" placeholder="Actual Date of Visit" name="adv" required><br><br>
                                
                                
                                <p><b> Distance of the industry From the College*</b></p><br><br>
                                <input type="text"  id="datepicker" placeholder="Distance  From  College" name="doi" required><br><br>
                      
                                                    </div>
                                <div >
                                    <h7 style="color: #3300ff;text-align: left;">Persons Met</h7><br><br>
                                
                                

                                    <p><b> Name*</b></p><br><br><br><br>
                                <input type="text"   placeholder="Name" name="pname" required><br><br>

                                    <p><b>Designation*</b></p><br><br><br><br>
                                <input type="text"   placeholder="Designation" name="pdg" required><br><br>
 
                                
                                <p><b>Number of Visit Made in the Semester*</b></p><br><br><br><br>
                                <input type="text"   placeholder="Number of Visit " name="nvmis" required><br><br>
                                
                                
                                
                                 <p><b>Number of Visit Made in the Academic Year*</b></p><br><br><br><br>
                                <input type="text"   placeholder="Number of Visit " name="nvmiay" required><br><br>
                                
                                
                                
                                 <p><b>Date of Presentation in the Review Meeting*</b></p><br><br><br><br>
                                <input type="text"  id="datepicker1" placeholder="Date of Presentation" name="dop" required><br>
                                
                                
                                
                                <p><b>Any Other*</b>&nbsp;&nbsp;&nbsp;<i style="color: #fff;font-size: 13px ">If No Other put 'NA'</i></p><br><br><br><br>
                                <input type="text"  id="datepicker1" placeholder="Any Other" name="any" required><br><br>
                                
                                
                                </div>
                                <br><br>
                                <center><button class="butt" onclick="myFunction()"><span>submit</span></center>
                    
                                                
                                 <br><br>
      
                        </div></form></section></div></div>                    
        </center>

    
    
    
    
    
    
</body>
  
 
</html> 

<?php  }?>